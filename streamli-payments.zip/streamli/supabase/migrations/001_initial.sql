-- ================================================
-- StreamLI Database Schema
-- Run this in Supabase SQL Editor
-- ================================================

-- Enable required extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ================================================
-- PROFILES TABLE
-- ================================================
CREATE TABLE IF NOT EXISTS public.profiles (
  id UUID REFERENCES auth.users(id) ON DELETE CASCADE PRIMARY KEY,
  email TEXT NOT NULL,
  full_name TEXT,
  avatar_url TEXT,
  is_admin BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- RLS for profiles
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can read own profile"
  ON public.profiles FOR SELECT
  USING (auth.uid() = id);

CREATE POLICY "Users can update own profile"
  ON public.profiles FOR UPDATE
  USING (auth.uid() = id);

CREATE POLICY "Users can insert own profile"
  ON public.profiles FOR INSERT
  WITH CHECK (auth.uid() = id);

CREATE POLICY "Admins can read all profiles"
  ON public.profiles FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM public.profiles
      WHERE id = auth.uid() AND is_admin = true
    )
  );

-- ================================================
-- PRODUCTS TABLE
-- ================================================
CREATE TABLE IF NOT EXISTS public.products (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT NOT NULL DEFAULT '',
  price_usd NUMERIC(10, 2) NOT NULL,
  category TEXT NOT NULL CHECK (category IN ('gaming', 'streaming', 'ai-tools', 'design-tools')),
  image_url TEXT NOT NULL DEFAULT '',
  badge TEXT,
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- RLS for products
ALTER TABLE public.products ENABLE ROW LEVEL SECURITY;

-- Anyone can read active products
CREATE POLICY "Anyone can read active products"
  ON public.products FOR SELECT
  USING (is_active = true);

-- Admins can do everything
CREATE POLICY "Admins can manage products"
  ON public.products FOR ALL
  USING (
    EXISTS (
      SELECT 1 FROM public.profiles
      WHERE id = auth.uid() AND is_admin = true
    )
  );

-- Trigger for updated_at
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_products_updated_at
  BEFORE UPDATE ON public.products
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

-- ================================================
-- ORDERS TABLE
-- ================================================
CREATE TABLE IF NOT EXISTS public.orders (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  user_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  product_id UUID REFERENCES public.products(id) ON DELETE SET NULL,
  amount_usd NUMERIC(10, 2) NOT NULL,
  currency TEXT NOT NULL DEFAULT 'MAD',
  amount_local NUMERIC(12, 2) NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending'
    CHECK (status IN ('pending', 'completed', 'failed', 'refunded')),
  stripe_session_id TEXT,
  delivery_code TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- RLS for orders
ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can read own orders"
  ON public.orders FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Service role can manage orders"
  ON public.orders FOR ALL
  USING (true); -- Controlled via service role key in API

CREATE POLICY "Admins can read all orders"
  ON public.orders FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM public.profiles
      WHERE id = auth.uid() AND is_admin = true
    )
  );

CREATE POLICY "Admins can update orders"
  ON public.orders FOR UPDATE
  USING (
    EXISTS (
      SELECT 1 FROM public.profiles
      WHERE id = auth.uid() AND is_admin = true
    )
  );

-- ================================================
-- AUTO-CREATE PROFILE ON SIGNUP
-- ================================================
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.profiles (id, email, full_name)
  VALUES (
    NEW.id,
    NEW.email,
    COALESCE(NEW.raw_user_meta_data->>'full_name', '')
  )
  ON CONFLICT (id) DO NOTHING;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE OR REPLACE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- ================================================
-- SEED PRODUCTS DATA
-- ================================================
INSERT INTO public.products (name, description, price_usd, category, image_url, badge, is_active) VALUES
  -- Gaming
  ('PlayStation Network $10', 'Add $10 to your PSN wallet. Works on PS4, PS5, and PlayStation Store.', 10.00, 'gaming', 'https://upload.wikimedia.org/wikipedia/commons/thumb/4/4e/Playstation_logo_colour.svg/200px-Playstation_logo_colour.svg.png', 'Popular', true),
  ('Xbox Gift Card $15', 'Microsoft Xbox $15 gift card for games, DLC, and Xbox Game Pass.', 15.00, 'gaming', 'https://upload.wikimedia.org/wikipedia/commons/thumb/f/f9/Xbox_one_logo.svg/200px-Xbox_one_logo.svg.png', 'Hot', true),
  ('Nintendo eShop $20', '$20 Nintendo eShop card for Switch games and content.', 20.00, 'gaming', 'https://upload.wikimedia.org/wikipedia/commons/thumb/0/0d/Nintendo.svg/200px-Nintendo.svg.png', NULL, true),
  ('Steam Wallet $20', 'Add $20 to your Steam wallet. Use for any game or DLC.', 20.00, 'gaming', 'https://upload.wikimedia.org/wikipedia/commons/thumb/8/83/Steam_icon_logo.svg/200px-Steam_icon_logo.svg.png', NULL, true),
  ('Roblox Gift Card $25', '2000 Robux or 1-month Roblox Premium. For all platforms.', 25.00, 'gaming', 'https://upload.wikimedia.org/wikipedia/commons/thumb/3/3a/Roblox_player_icon_black.svg/200px-Roblox_player_icon_black.svg.png', 'New', true),
  ('V-Bucks 2800', '2800 Fortnite V-Bucks for cosmetics, Battle Pass and more.', 20.00, 'gaming', 'https://upload.wikimedia.org/wikipedia/commons/thumb/8/82/Fortnite_F_lettermark_logo.png/200px-Fortnite_F_lettermark_logo.png', NULL, true),
  -- Streaming
  ('Spotify Premium 1 Month', 'Ad-free music, offline listening, unlimited skips.', 9.99, 'streaming', 'https://upload.wikimedia.org/wikipedia/commons/thumb/1/19/Spotify_logo_without_text.svg/200px-Spotify_logo_without_text.svg.png', 'Popular', true),
  ('Apple Music 1 Month', '100M+ songs, spatial audio, lyrics, and more.', 10.99, 'streaming', 'https://upload.wikimedia.org/wikipedia/commons/thumb/5/5f/Apple_Music_icon.svg/200px-Apple_Music_icon.svg.png', NULL, true),
  ('Netflix Standard 1 Month', 'Stream in Full HD on 2 screens simultaneously.', 15.49, 'streaming', 'https://upload.wikimedia.org/wikipedia/commons/thumb/0/08/Netflix_2015_logo.svg/200px-Netflix_2015_logo.svg.png', 'Hot', true),
  ('Prime Video 1 Month', 'Amazon original series, movies, and exclusive content.', 8.99, 'streaming', 'https://upload.wikimedia.org/wikipedia/commons/thumb/1/11/Amazon_Prime_Video_logo.svg/200px-Amazon_Prime_Video_logo.svg.png', NULL, true),
  -- AI Tools
  ('ChatGPT Plus 1 Month', 'GPT-4, DALL-E 3, faster responses and priority access.', 20.00, 'ai-tools', 'https://upload.wikimedia.org/wikipedia/commons/thumb/0/04/ChatGPT_logo.svg/200px-ChatGPT_logo.svg.png', 'Trending', true),
  -- Design Tools
  ('Canva Pro 1 Month', 'Premium templates, Brand Kit, background remover & more.', 12.99, 'design-tools', 'https://upload.wikimedia.org/wikipedia/commons/thumb/b/bb/Canva_Logo.svg/200px-Canva_Logo.svg.png', 'Popular', true),
  ('CapCut Pro 1 Month', 'Advanced video editing with AI tools, effects & export.', 7.99, 'design-tools', 'https://upload.wikimedia.org/wikipedia/commons/thumb/7/70/CapCut_Logo.svg/200px-CapCut_Logo.svg.png', 'New', true)
ON CONFLICT DO NOTHING;

-- ================================================
-- ADMIN USER (update after signup)
-- Run this after creating your admin account:
-- UPDATE public.profiles SET is_admin = true WHERE email = 'your@email.com';
-- ================================================
