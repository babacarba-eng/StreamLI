-- ================================================
-- StreamLI Migration 002: Multi-Payment Support
-- Run this AFTER 001_initial.sql
-- ================================================

-- Add payment method columns to orders
ALTER TABLE public.orders
  ADD COLUMN IF NOT EXISTS payment_method TEXT NOT NULL DEFAULT 'card'
    CHECK (payment_method IN ('card', 'paypal', 'orange_money', 'wave', 'cashplus')),
  ADD COLUMN IF NOT EXISTS payment_reference TEXT,
  ADD COLUMN IF NOT EXISTS orange_money_pay_token TEXT,
  ADD COLUMN IF NOT EXISTS wave_checkout_id TEXT,
  ADD COLUMN IF NOT EXISTS cashplus_reference TEXT;

-- Make stripe_session_id nullable (not all methods use Stripe)
ALTER TABLE public.orders
  ALTER COLUMN stripe_session_id DROP NOT NULL;

-- Add awaiting_confirmation to the status check constraint
ALTER TABLE public.orders DROP CONSTRAINT IF EXISTS orders_status_check;
ALTER TABLE public.orders
  ADD CONSTRAINT orders_status_check
    CHECK (status IN ('pending', 'awaiting_confirmation', 'completed', 'failed', 'refunded'));

-- Index for fast webhook lookups
CREATE INDEX IF NOT EXISTS idx_orders_orange_money_pay_token
  ON public.orders (orange_money_pay_token)
  WHERE orange_money_pay_token IS NOT NULL;

CREATE INDEX IF NOT EXISTS idx_orders_wave_checkout_id
  ON public.orders (wave_checkout_id)
  WHERE wave_checkout_id IS NOT NULL;

CREATE INDEX IF NOT EXISTS idx_orders_cashplus_reference
  ON public.orders (cashplus_reference)
  WHERE cashplus_reference IS NOT NULL;

CREATE INDEX IF NOT EXISTS idx_orders_payment_method
  ON public.orders (payment_method);

CREATE INDEX IF NOT EXISTS idx_orders_status
  ON public.orders (status);

-- ================================================
-- Example: manually set a cashplus order to confirmed (admin use)
-- UPDATE public.orders
--   SET status = 'completed', delivery_code = 'XXXX-XXXX-XXXX-XXXX'
--   WHERE cashplus_reference = 'STLI-ABCD-EFGH';
-- ================================================
