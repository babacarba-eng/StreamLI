/**
 * Orange Money API Client
 * Covers: Senegal, Côte d'Ivoire, Mali, Burkina Faso, Cameroon
 *
 * Docs: https://developer.orange.com/apis/om-webpay/getting-started
 *
 * Flow:
 *  1. getAccessToken()  → Bearer token (valid 90 days, cache it)
 *  2. initiatePayment() → pay_token + payment_url
 *  3. Customer approves via OTP or USSD push on their phone
 *  4. Orange sends a POST callback to ORANGE_MONEY_CALLBACK_URL
 *  5. verifyPayment()   → confirm status server-side
 */

const OM_BASE_URL = process.env.ORANGE_MONEY_BASE_URL || 'https://api.orange.com/orange-money-webpay/dev/v1'
const OM_CLIENT_ID = process.env.ORANGE_MONEY_CLIENT_ID!
const OM_CLIENT_SECRET = process.env.ORANGE_MONEY_CLIENT_SECRET!
const OM_MERCHANT_KEY = process.env.ORANGE_MONEY_MERCHANT_KEY!
const OM_CURRENCY = process.env.ORANGE_MONEY_CURRENCY || 'OUV' // XOF for FCFA zone

// ── Token cache (in-process; use Redis in production multi-instance setups) ──
let _tokenCache: { token: string; expiresAt: number } | null = null

export async function getAccessToken(): Promise<string> {
  if (_tokenCache && Date.now() < _tokenCache.expiresAt) {
    return _tokenCache.token
  }

  const credentials = Buffer.from(`${OM_CLIENT_ID}:${OM_CLIENT_SECRET}`).toString('base64')

  const res = await fetch('https://api.orange.com/oauth/v3/token', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded',
      Authorization: `Basic ${credentials}`,
    },
    body: 'grant_type=client_credentials',
  })

  if (!res.ok) {
    const err = await res.text()
    throw new Error(`Orange Money auth failed: ${err}`)
  }

  const data = await res.json()

  _tokenCache = {
    token: data.access_token,
    expiresAt: Date.now() + (data.expires_in - 60) * 1000, // 60s safety margin
  }

  return _tokenCache.token
}

export interface OrangeMoneyPaymentParams {
  orderId: string
  amountFcfa: number // amount in FCFA (XOF)
  customerPhone: string // e.g. "+221771234567"
  productName: string
  returnUrl: string
  cancelUrl: string
  notifUrl: string // webhook URL
}

export interface OrangeMoneyPaymentResult {
  payToken: string
  paymentUrl: string
  notifToken: string
}

export async function initiatePayment(params: OrangeMoneyPaymentParams): Promise<OrangeMoneyPaymentResult> {
  const token = await getAccessToken()

  const body = {
    merchant_key: OM_MERCHANT_KEY,
    currency: OM_CURRENCY,
    order_id: params.orderId,
    amount: params.amountFcfa,
    return_url: params.returnUrl,
    cancel_url: params.cancelUrl,
    notif_url: params.notifUrl,
    lang: 'en',
    reference: `STREAMLI-${params.orderId}`,
  }

  const res = await fetch(`${OM_BASE_URL}/webpayment`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`,
    },
    body: JSON.stringify(body),
  })

  const data = await res.json()

  if (!res.ok || !data.pay_token) {
    throw new Error(data.message || 'Orange Money payment initiation failed')
  }

  return {
    payToken: data.pay_token,
    paymentUrl: data.payment_url,
    notifToken: data.notif_token,
  }
}

export interface OrangeMoneyVerifyResult {
  status: 'SUCCESSFULL' | 'FAILED' | 'PENDING' | 'CANCELLED'
  orderId: string
  amount: number
  txnId: string
}

export async function verifyPayment(payToken: string): Promise<OrangeMoneyVerifyResult> {
  const token = await getAccessToken()

  const res = await fetch(`${OM_BASE_URL}/webpayment/${payToken}`, {
    headers: {
      Authorization: `Bearer ${token}`,
    },
  })

  const data = await res.json()

  if (!res.ok) {
    throw new Error(data.message || 'Could not verify Orange Money payment')
  }

  return {
    status: data.status,
    orderId: data.order_id,
    amount: data.amount,
    txnId: data.txnid,
  }
}

/** Parse and validate the webhook payload Orange sends to notif_url */
export function parseWebhookPayload(body: Record<string, any>) {
  return {
    status: body.status as string,
    orderId: body.order_id as string,
    payToken: body.pay_token as string,
    amount: Number(body.amount),
    txnId: body.txnid as string,
    message: body.message as string,
  }
}
