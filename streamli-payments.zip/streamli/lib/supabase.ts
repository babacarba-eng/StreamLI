import { createClient } from '@supabase/supabase-js'
import { createClientComponentClient, createServerComponentClient } from '@supabase/auth-helpers-nextjs'
import { cookies } from 'next/headers'

export type Database = {
  public: {
    Tables: {
      profiles: {
        Row: {
          id: string
          email: string
          full_name: string | null
          avatar_url: string | null
          is_admin: boolean
          created_at: string
        }
        Insert: {
          id: string
          email: string
          full_name?: string | null
          avatar_url?: string | null
          is_admin?: boolean
          created_at?: string
        }
        Update: {
          email?: string
          full_name?: string | null
          avatar_url?: string | null
          is_admin?: boolean
        }
      }
      products: {
        Row: {
          id: string
          name: string
          description: string
          price_usd: number
          category: string
          image_url: string
          badge: string | null
          is_active: boolean
          created_at: string
          updated_at: string
        }
        Insert: {
          name: string
          description: string
          price_usd: number
          category: string
          image_url: string
          badge?: string | null
          is_active?: boolean
        }
        Update: {
          name?: string
          description?: string
          price_usd?: number
          category?: string
          image_url?: string
          badge?: string | null
          is_active?: boolean
          updated_at?: string
        }
      }
      orders: {
        Row: {
          id: string
          user_id: string
          product_id: string
          amount_usd: number
          currency: string
          amount_local: number
          status: string
          stripe_session_id: string
          delivery_code: string | null
          created_at: string
        }
        Insert: {
          user_id: string
          product_id: string
          amount_usd: number
          currency: string
          amount_local: number
          status?: string
          stripe_session_id: string
          delivery_code?: string | null
        }
        Update: {
          status?: string
          delivery_code?: string | null
        }
      }
    }
  }
}

// Client-side Supabase client
export const createBrowserClient = () =>
  createClientComponentClient<Database>()

// Server-side Supabase client (Server Components)
export const createServerClient = () =>
  createServerComponentClient<Database>({ cookies })

// Admin client (uses service role, server-side only)
export const createAdminClient = () =>
  createClient<Database>(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!
  )
