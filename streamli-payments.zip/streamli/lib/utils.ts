import { type ClassValue, clsx } from 'clsx'
import { twMerge } from 'tailwind-merge'
import { Currency, CURRENCIES, CurrencyConfig } from '@/types'

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export function formatPrice(priceUsd: number, currency: Currency): string {
  const config = CURRENCIES.find(c => c.code === currency)!
  const converted = priceUsd * config.rate

  if (currency === 'USD') {
    return `$${converted.toFixed(2)}`
  } else if (currency === 'MAD') {
    return `${Math.round(converted)} MAD`
  } else {
    return `${Math.round(converted).toLocaleString()} FCFA`
  }
}

export function getCurrencyConfig(currency: Currency): CurrencyConfig {
  return CURRENCIES.find(c => c.code === currency)!
}

export function generateDeliveryCode(): string {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'
  let code = ''
  for (let i = 0; i < 16; i++) {
    if (i > 0 && i % 4 === 0) code += '-'
    code += chars[Math.floor(Math.random() * chars.length)]
  }
  return code
}

export function getBadgeColor(badge: string): string {
  const map: Record<string, string> = {
    Popular: 'bg-electric-500/20 text-electric-400 border-electric-500/30',
    Hot: 'bg-red-500/20 text-red-400 border-red-500/30',
    New: 'bg-green-500/20 text-green-400 border-green-500/30',
    Trending: 'bg-purple-500/20 text-purple-400 border-purple-500/30',
  }
  return map[badge] || 'bg-gray-500/20 text-gray-400 border-gray-500/30'
}
