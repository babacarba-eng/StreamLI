/**
 * Wave API Client
 * Coverage: Senegal, Côte d'Ivoire, Mali, Uganda, Tanzania
 *
 * Docs: https://docs.wave.com/business/api
 *
 * Flow:
 *  1. createCheckoutSession() → wave_launch_url (redirect or QR code)
 *  2. Customer opens Wave app and approves payment
 *  3. Wave sends webhook POST to WAVE_WEBHOOK_URL
 *  4. getCheckoutSession() → verify status server-side
 */

const WAVE_BASE_URL = 'https://api.wave.com/v1'
const WAVE_API_KEY = process.env.WAVE_API_KEY!
const WAVE_WEBHOOK_SECRET = process.env.WAVE_WEBHOOK_SECRET!

function waveHeaders() {
  return {
    'Content-Type': 'application/json',
    Authorization: `Bearer ${WAVE_API_KEY}`,
  }
}

export interface WaveCheckoutParams {
  orderId: string
  amountFcfa: number       // Wave uses whole FCFA amounts
  currency: 'XOF' | 'XAF' // XOF = UEMOA zone, XAF = CEMAC zone
  productName: string
  clientReference?: string  // your internal reference
  successUrl: string
  errorUrl: string
}

export interface WaveCheckoutSession {
  id: string
  wavelaunchUrl: string  // deep-link that opens Wave app
  checkoutStatus: 'pending' | 'processing' | 'succeeded' | 'failed' | 'expired'
  amountTotal: number
  currency: string
  clientReference: string
  when: string
  expiresAt: string
}

export async function createCheckoutSession(params: WaveCheckoutParams): Promise<WaveCheckoutSession> {
  const res = await fetch(`${WAVE_BASE_URL}/checkout/sessions`, {
    method: 'POST',
    headers: waveHeaders(),
    body: JSON.stringify({
      amount: String(params.amountFcfa),
      currency: params.currency,
      error_url: params.errorUrl,
      success_url: params.successUrl,
      client_reference: params.clientReference || params.orderId,
    }),
  })

  const data = await res.json()

  if (!res.ok) {
    throw new Error(data.message || `Wave checkout failed: ${res.status}`)
  }

  return {
    id: data.id,
    wavelaunchUrl: data.wave_launch_url,
    checkoutStatus: data.checkout_status,
    amountTotal: data.amount_total,
    currency: data.currency,
    clientReference: data.client_reference,
    when: data.when,
    expiresAt: data.expires_at ?? new Date(Date.now() + 20 * 60 * 1000).toISOString(), // 20 min default
  }
}

export async function getCheckoutSession(sessionId: string): Promise<WaveCheckoutSession> {
  const res = await fetch(`${WAVE_BASE_URL}/checkout/sessions/${sessionId}`, {
    headers: waveHeaders(),
  })

  const data = await res.json()

  if (!res.ok) {
    throw new Error(data.message || 'Could not fetch Wave session')
  }

  return {
    id: data.id,
    wavelaunchUrl: data.wave_launch_url,
    checkoutStatus: data.checkout_status,
    amountTotal: data.amount_total,
    currency: data.currency,
    clientReference: data.client_reference,
    when: data.when,
    expiresAt: data.expires_at,
  }
}

/**
 * Validate Wave webhook signature.
 * Wave sends: Wave-Signature: t=<timestamp>,v1=<hmac>
 */
export function validateWebhookSignature(
  rawBody: string,
  signatureHeader: string
): boolean {
  const crypto = require('crypto')
  const parts = Object.fromEntries(
    signatureHeader.split(',').map(p => p.split('=') as [string, string])
  )

  const timestamp = parts['t']
  const receivedHmac = parts['v1']
  if (!timestamp || !receivedHmac) return false

  // Reject requests older than 5 minutes
  if (Math.abs(Date.now() / 1000 - Number(timestamp)) > 300) return false

  const payload = `${timestamp}.${rawBody}`
  const expected = crypto
    .createHmac('sha256', WAVE_WEBHOOK_SECRET)
    .update(payload)
    .digest('hex')

  return crypto.timingSafeEqual(
    Buffer.from(receivedHmac, 'hex'),
    Buffer.from(expected, 'hex')
  )
}

export interface WaveWebhookPayload {
  type: 'checkout.session.completed' | 'checkout.session.failed' | 'checkout.session.expired'
  data: {
    id: string
    checkout_status: string
    amount_total: number
    currency: string
    client_reference: string
  }
}

export function parseWebhookPayload(body: any): WaveWebhookPayload {
  return body as WaveWebhookPayload
}
