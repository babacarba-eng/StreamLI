'use client'

import { useState, useEffect, useCallback } from 'react'
import { useRouter } from 'next/navigation'
import {
  X, ChevronRight, Loader2, CheckCircle2, Copy, CheckCheck,
  MapPin, Clock, Shield, AlertCircle, ExternalLink, Phone,
  CreditCard, Wallet, Smartphone, Banknote, ArrowLeft,
} from 'lucide-react'
import { Product, PaymentMethod, PAYMENT_METHODS, CURRENCIES, Currency } from '@/types'
import { useCurrencyStore } from '@/hooks/useCurrency'
import { formatPrice, cn } from '@/lib/utils'
import { createBrowserClient } from '@/lib/supabase'
import toast from 'react-hot-toast'

interface CheckoutModalProps {
  product: Product
  onClose: () => void
}

type Step = 'select' | 'phone' | 'processing' | 'cashplus_instructions' | 'done'

interface CashPlusResult {
  orderId: string
  reference: string
  amountMad: number
  expiresAt: string
  instructions: string[]
  agentLocatorUrl: string
}

const METHOD_ICONS: Record<PaymentMethod, React.ReactNode> = {
  card: <CreditCard className="w-5 h-5" />,
  paypal: <Wallet className="w-5 h-5" />,
  orange_money: <Smartphone className="w-5 h-5" />,
  wave: <Smartphone className="w-5 h-5" />,
  cashplus: <Banknote className="w-5 h-5" />,
}

const PROCESSING_TIME_ICONS: Record<string, React.ReactNode> = {
  'Instant': <CheckCircle2 className="w-3.5 h-3.5 text-green-400" />,
  '~1 min': <Clock className="w-3.5 h-3.5 text-amber-400" />,
  '~30 min': <Clock className="w-3.5 h-3.5 text-orange-400" />,
}

export default function CheckoutModal({ product, onClose }: CheckoutModalProps) {
  const { currency } = useCurrencyStore()
  const [step, setStep] = useState<Step>('select')
  const [selectedMethod, setSelectedMethod] = useState<PaymentMethod | null>(null)
  const [phone, setPhone] = useState('')
  const [loading, setLoading] = useState(false)
  const [cashPlusResult, setCashPlusResult] = useState<CashPlusResult | null>(null)
  const [copiedRef, setCopiedRef] = useState(false)
  const [copiedStep, setCopiedStep] = useState<number | null>(null)
  const router = useRouter()
  const supabase = createBrowserClient()

  // Filter methods by current currency
  const availableMethods = PAYMENT_METHODS.filter(m =>
    m.currencies.includes(currency as Currency)
  )

  const handleMethodSelect = (method: PaymentMethod) => {
    setSelectedMethod(method)
    // Orange Money and Wave need phone number
    if (method === 'orange_money' || method === 'wave') {
      setStep('phone')
    } else {
      handleCheckout(method, '')
    }
  }

  const handleCheckout = useCallback(async (method: PaymentMethod, phoneNum: string) => {
    setLoading(true)
    setStep('processing')

    try {
      const res = await fetch('/api/checkout', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          productId: product.id,
          currency,
          paymentMethod: method,
          customerPhone: phoneNum,
        }),
      })

      const data = await res.json()

      if (!res.ok) throw new Error(data.error || 'Checkout failed')

      if (data.method === 'redirect') {
        // Card, PayPal, Orange Money, Wave → redirect to payment page
        window.location.href = data.url
      } else if (data.method === 'cashplus') {
        setCashPlusResult(data)
        setStep('cashplus_instructions')
        setLoading(false)
      }
    } catch (err: any) {
      toast.error(err.message || 'Payment failed')
      setStep('select')
      setLoading(false)
    }
  }, [product.id, currency])

  const handlePhoneSubmit = () => {
    if (!phone || phone.length < 8) {
      toast.error('Please enter a valid phone number')
      return
    }
    handleCheckout(selectedMethod!, phone)
  }

  const copyReference = () => {
    if (cashPlusResult) {
      navigator.clipboard.writeText(cashPlusResult.reference)
      setCopiedRef(true)
      toast.success('Reference copied!')
      setTimeout(() => setCopiedRef(false), 2000)
    }
  }

  const copyStep = (text: string, i: number) => {
    navigator.clipboard.writeText(text)
    setCopiedStep(i)
    setTimeout(() => setCopiedStep(null), 1500)
  }

  const goToDashboard = () => {
    onClose()
    router.push('/dashboard')
  }

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4">
      {/* Backdrop */}
      <div
        className="absolute inset-0 bg-black/70 backdrop-blur-sm"
        onClick={onClose}
      />

      {/* Modal */}
      <div className={cn(
        'relative w-full sm:max-w-lg bg-navy-900 border border-white/10 shadow-2xl',
        'rounded-t-3xl sm:rounded-2xl overflow-hidden',
        'max-h-[92vh] flex flex-col',
        'animate-slide-up'
      )}>
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-white/5 flex-shrink-0">
          <div className="flex items-center gap-3">
            {(step === 'phone') && (
              <button
                onClick={() => setStep('select')}
                className="p-1.5 rounded-lg text-white/40 hover:text-white hover:bg-white/5 transition-colors"
              >
                <ArrowLeft className="w-4 h-4" />
              </button>
            )}
            <div>
              <h2 className="font-display font-bold text-lg text-white leading-none">
                {step === 'select' && 'Choose Payment'}
                {step === 'phone' && 'Enter Phone Number'}
                {step === 'processing' && 'Processing…'}
                {step === 'cashplus_instructions' && 'Pay at Agent'}
                {step === 'done' && 'Order Complete!'}
              </h2>
              {step === 'select' && (
                <p className="text-white/40 text-xs mt-0.5 truncate max-w-[260px]">
                  {product.name}
                </p>
              )}
            </div>
          </div>
          {step !== 'processing' && (
            <button
              onClick={onClose}
              className="p-2 rounded-xl text-white/40 hover:text-white hover:bg-white/5 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          )}
        </div>

        {/* Scrollable body */}
        <div className="overflow-y-auto flex-1">

          {/* ── Product summary strip ── */}
          {(step === 'select' || step === 'phone') && (
            <div className="flex items-center gap-3 px-6 py-3 bg-navy-800/50 border-b border-white/5">
              <div className="w-10 h-10 bg-navy-700 rounded-xl flex items-center justify-center overflow-hidden">
                <img src={product.image_url} alt={product.name}
                  className="w-8 h-8 object-contain"
                  onError={e => { (e.target as HTMLImageElement).style.display = 'none' }}
                />
              </div>
              <div className="flex-1 min-w-0">
                <div className="font-semibold text-white text-sm truncate">{product.name}</div>
                <div className="text-white/40 text-xs capitalize">{product.category.replace('-', ' ')}</div>
              </div>
              <div className="text-right">
                <div className="font-display font-bold text-white">{formatPrice(product.price_usd, currency as Currency)}</div>
                {currency !== 'USD' && (
                  <div className="text-white/30 text-xs">${product.price_usd} USD</div>
                )}
              </div>
            </div>
          )}

          {/* ── Step: Select Payment Method ── */}
          {step === 'select' && (
            <div className="p-4 space-y-2">
              {availableMethods.length === 0 ? (
                <div className="text-center py-8 text-white/40">
                  <AlertCircle className="w-8 h-8 mx-auto mb-2 opacity-50" />
                  <p className="text-sm">No payment methods available for {currency}.</p>
                  <p className="text-xs mt-1">Try switching currency in the navbar.</p>
                </div>
              ) : (
                availableMethods.map(method => (
                  <button
                    key={method.id}
                    onClick={() => handleMethodSelect(method.id)}
                    className={cn(
                      'w-full flex items-center gap-3 p-3.5 rounded-xl border transition-all duration-200 text-left group',
                      'bg-navy-800/50 border-white/8 hover:border-electric-500/30 hover:bg-navy-700/60',
                      'hover:shadow-glow-sm'
                    )}
                  >
                    {/* Icon */}
                    <div className={cn(
                      'w-11 h-11 rounded-xl flex items-center justify-center flex-shrink-0 text-xl',
                      `bg-gradient-to-br ${method.color}`
                    )}>
                      {method.icon}
                    </div>

                    {/* Label */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-semibold text-white text-sm">{method.label}</span>
                        {method.badge && (
                          <span className="text-xs px-1.5 py-0.5 rounded-full bg-electric-500/15 text-electric-400 border border-electric-500/20 font-medium">
                            {method.badge}
                          </span>
                        )}
                      </div>
                      <div className="text-white/40 text-xs mt-0.5 truncate">{method.description}</div>
                    </div>

                    {/* Processing time + arrow */}
                    <div className="flex items-center gap-2 flex-shrink-0">
                      <div className="flex items-center gap-1 text-xs text-white/30">
                        {PROCESSING_TIME_ICONS[method.processingTime] || <Clock className="w-3.5 h-3.5" />}
                        <span>{method.processingTime}</span>
                      </div>
                      <ChevronRight className="w-4 h-4 text-white/20 group-hover:text-white/60 group-hover:translate-x-0.5 transition-all" />
                    </div>
                  </button>
                ))
              )}

              {/* Security note */}
              <div className="flex items-center justify-center gap-2 pt-2 text-xs text-white/20">
                <Shield className="w-3.5 h-3.5" />
                <span>All transactions are encrypted and secure</span>
              </div>
            </div>
          )}

          {/* ── Step: Phone Number ── */}
          {step === 'phone' && selectedMethod && (
            <div className="p-6 space-y-5">
              <div className="flex items-center gap-3 p-4 bg-navy-800/50 rounded-xl border border-white/8">
                <div className={cn(
                  'w-10 h-10 rounded-xl flex items-center justify-center text-xl',
                  `bg-gradient-to-br ${PAYMENT_METHODS.find(m => m.id === selectedMethod)?.color}`
                )}>
                  {PAYMENT_METHODS.find(m => m.id === selectedMethod)?.icon}
                </div>
                <div>
                  <div className="font-semibold text-white text-sm">
                    {PAYMENT_METHODS.find(m => m.id === selectedMethod)?.label}
                  </div>
                  <div className="text-white/40 text-xs">
                    {selectedMethod === 'orange_money'
                      ? 'Enter the Orange Money number to receive the payment prompt'
                      : 'Enter the Wave-registered number for this payment'}
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-white/70 mb-2">
                  Mobile Phone Number
                </label>
                <div className="relative">
                  <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-white/30" />
                  <input
                    type="tel"
                    value={phone}
                    onChange={e => setPhone(e.target.value)}
                    placeholder="+221 77 123 45 67"
                    className="input-field pl-10"
                    autoFocus
                  />
                </div>
                <p className="text-white/30 text-xs mt-1.5">
                  Include country code (e.g. +221 for Senegal, +225 for Côte d'Ivoire)
                </p>
              </div>

              <button
                onClick={handlePhoneSubmit}
                className="btn-primary w-full py-3.5"
              >
                Continue to Payment
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          )}

          {/* ── Step: Processing ── */}
          {step === 'processing' && (
            <div className="flex flex-col items-center justify-center py-16 px-6 text-center">
              <div className="relative mb-6">
                <div className="w-16 h-16 rounded-full border-2 border-electric-500/20 border-t-electric-500 animate-spin" />
                <div className="absolute inset-0 flex items-center justify-center">
                  {selectedMethod && (
                    <span className="text-xl">
                      {PAYMENT_METHODS.find(m => m.id === selectedMethod)?.icon}
                    </span>
                  )}
                </div>
              </div>
              <h3 className="font-display font-bold text-xl text-white mb-2">
                {selectedMethod === 'cashplus' ? 'Creating Order…' : 'Redirecting to Payment…'}
              </h3>
              <p className="text-white/40 text-sm max-w-xs">
                {selectedMethod === 'orange_money' && 'Check your phone — you\'ll receive an OTP or USSD push to approve.'}
                {selectedMethod === 'wave' && 'You\'ll be redirected to Wave to complete the payment.'}
                {selectedMethod === 'cashplus' && 'Generating your payment reference…'}
                {(selectedMethod === 'card' || selectedMethod === 'paypal') && 'Connecting to secure checkout…'}
              </p>
            </div>
          )}

          {/* ── Step: CashPlus Instructions ── */}
          {step === 'cashplus_instructions' && cashPlusResult && (
            <div className="p-5 space-y-5">
              {/* Reference code */}
              <div className="bg-navy-800/60 border border-green-500/20 rounded-2xl p-5 text-center">
                <div className="text-white/50 text-xs uppercase tracking-widest mb-2 font-mono">
                  Your Payment Reference
                </div>
                <div className="font-mono font-bold text-3xl text-white tracking-[0.2em] mb-3">
                  {cashPlusResult.reference}
                </div>
                <button
                  onClick={copyReference}
                  className={cn(
                    'inline-flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium transition-all',
                    copiedRef
                      ? 'bg-green-500/20 text-green-400 border border-green-500/30'
                      : 'bg-navy-700/60 text-white/60 border border-white/10 hover:border-electric-500/30 hover:text-white'
                  )}
                >
                  {copiedRef ? <CheckCheck className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                  {copiedRef ? 'Copied!' : 'Copy Reference'}
                </button>
              </div>

              {/* Amount */}
              <div className="flex items-center justify-between p-3.5 bg-navy-800/40 rounded-xl border border-white/5">
                <span className="text-white/50 text-sm">Amount to pay</span>
                <span className="font-display font-bold text-white text-lg">
                  {cashPlusResult.amountMad.toLocaleString()} MAD
                </span>
              </div>

              {/* Expiry */}
              <div className="flex items-center gap-2 text-amber-400/80 text-xs bg-amber-500/10 border border-amber-500/20 rounded-xl px-3 py-2.5">
                <Clock className="w-3.5 h-3.5 flex-shrink-0" />
                <span>
                  Reference expires{' '}
                  <strong>
                    {new Date(cashPlusResult.expiresAt).toLocaleString('en-GB', {
                      day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit'
                    })}
                  </strong>
                </span>
              </div>

              {/* Instructions */}
              <div>
                <h4 className="text-white/60 text-xs uppercase tracking-widest font-semibold mb-3">
                  How to pay
                </h4>
                <div className="space-y-2">
                  {cashPlusResult.instructions.map((step, i) => (
                    <div
                      key={i}
                      className="flex items-start gap-3 p-3 bg-navy-800/30 rounded-xl border border-white/5 group"
                    >
                      <div className="w-6 h-6 rounded-full bg-electric-500/20 text-electric-400 text-xs font-bold flex items-center justify-center flex-shrink-0 mt-0.5">
                        {i + 1}
                      </div>
                      <p className="text-white/70 text-sm flex-1 leading-relaxed">{step}</p>
                      <button
                        onClick={() => copyStep(step, i)}
                        className="opacity-0 group-hover:opacity-100 transition-opacity p-1 rounded text-white/30 hover:text-white/60"
                      >
                        {copiedStep === i ? <CheckCheck className="w-3.5 h-3.5 text-green-400" /> : <Copy className="w-3.5 h-3.5" />}
                      </button>
                    </div>
                  ))}
                </div>
              </div>

              {/* Agent locator */}
              <a
                href={cashPlusResult.agentLocatorUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-center gap-2 p-3 rounded-xl border border-white/10 text-white/50 hover:text-white hover:border-electric-500/30 transition-all text-sm"
              >
                <MapPin className="w-4 h-4 text-electric-400" />
                Find nearest CashPlus agent
                <ExternalLink className="w-3.5 h-3.5 opacity-50" />
              </a>

              {/* CTA buttons */}
              <div className="flex gap-3 pt-1">
                <button
                  onClick={onClose}
                  className="btn-secondary flex-1 py-3"
                >
                  Continue Shopping
                </button>
                <button
                  onClick={goToDashboard}
                  className="btn-primary flex-1 py-3"
                >
                  View Order
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
