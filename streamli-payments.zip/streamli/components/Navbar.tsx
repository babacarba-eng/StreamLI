'use client'

import { useState, useEffect } from 'react'
import Link from 'next/link'
import { usePathname, useRouter } from 'next/navigation'
import { Menu, X, Zap, ShoppingBag, LogOut, LayoutDashboard, Shield } from 'lucide-react'
import { createBrowserClient } from '@/lib/supabase'
import { useCurrencyStore } from '@/hooks/useCurrency'
import { CURRENCIES } from '@/types'
import { cn } from '@/lib/utils'
import toast from 'react-hot-toast'

const NAV_LINKS = [
  { href: '/', label: 'Home' },
  { href: '/marketplace', label: 'Marketplace' },
]

export default function Navbar() {
  const [menuOpen, setMenuOpen] = useState(false)
  const [scrolled, setScrolled] = useState(false)
  const [user, setUser] = useState<any>(null)
  const [isAdmin, setIsAdmin] = useState(false)
  const pathname = usePathname()
  const router = useRouter()
  const supabase = createBrowserClient()
  const { currency, setCurrency } = useCurrencyStore()

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 20)
    window.addEventListener('scroll', handleScroll)
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  useEffect(() => {
    const getUser = async () => {
      const { data: { session } } = await supabase.auth.getSession()
      if (session?.user) {
        setUser(session.user)
        const { data: profile } = await supabase
          .from('profiles')
          .select('is_admin')
          .eq('id', session.user.id)
          .single()
        setIsAdmin(profile?.is_admin || false)
      }
    }
    getUser()

    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      setUser(session?.user ?? null)
    })
    return () => subscription.unsubscribe()
  }, [])

  const handleSignOut = async () => {
    await supabase.auth.signOut()
    setUser(null)
    toast.success('Signed out successfully')
    router.push('/')
  }

  return (
    <nav className={cn(
      'fixed top-0 left-0 right-0 z-50 transition-all duration-300',
      scrolled
        ? 'bg-navy-900/95 backdrop-blur-xl border-b border-white/5 shadow-lg shadow-black/20'
        : 'bg-transparent'
    )}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-2 group">
            <div className="relative w-8 h-8">
              <div className="absolute inset-0 bg-electric-500 rounded-lg opacity-20 group-hover:opacity-40 transition-opacity animate-glow-pulse" />
              <div className="relative w-8 h-8 bg-gradient-to-br from-electric-400 to-accent-500 rounded-lg flex items-center justify-center shadow-glow-sm">
                <Zap className="w-4 h-4 text-white fill-white" />
              </div>
            </div>
            <span className="font-display font-bold text-xl text-white">
              Stream<span className="gradient-text">LI</span>
            </span>
          </Link>

          {/* Desktop nav */}
          <div className="hidden md:flex items-center gap-6">
            {NAV_LINKS.map(link => (
              <Link
                key={link.href}
                href={link.href}
                className={cn(
                  'text-sm font-medium transition-colors',
                  pathname === link.href
                    ? 'text-electric-400'
                    : 'text-white/60 hover:text-white'
                )}
              >
                {link.label}
              </Link>
            ))}
          </div>

          {/* Right side */}
          <div className="hidden md:flex items-center gap-3">
            {/* Currency switcher */}
            <div className="relative">
              <select
                value={currency}
                onChange={e => setCurrency(e.target.value as any)}
                className="appearance-none bg-navy-700/60 border border-white/10 text-white text-sm rounded-lg px-3 py-1.5 pr-7 cursor-pointer hover:border-electric-500/30 focus:outline-none focus:border-electric-500/50 transition-colors"
              >
                {CURRENCIES.map(c => (
                  <option key={c.code} value={c.code}>
                    {c.flag} {c.code}
                  </option>
                ))}
              </select>
              <div className="pointer-events-none absolute right-2 top-1/2 -translate-y-1/2 text-white/40">
                ▾
              </div>
            </div>

            {user ? (
              <div className="flex items-center gap-2">
                <Link href="/dashboard" className="btn-secondary text-sm px-4 py-2">
                  <LayoutDashboard className="w-4 h-4" />
                  Dashboard
                </Link>
                {isAdmin && (
                  <Link href="/admin" className="btn-secondary text-sm px-4 py-2 border-accent-500/30 text-accent-400">
                    <Shield className="w-4 h-4" />
                    Admin
                  </Link>
                )}
                <button onClick={handleSignOut} className="p-2 text-white/40 hover:text-red-400 transition-colors">
                  <LogOut className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <Link href="/login" className="btn-secondary text-sm px-4 py-2">Sign In</Link>
                <Link href="/signup" className="btn-primary text-sm px-4 py-2">
                  <ShoppingBag className="w-4 h-4" />
                  Get Started
                </Link>
              </div>
            )}
          </div>

          {/* Mobile menu button */}
          <button
            onClick={() => setMenuOpen(!menuOpen)}
            className="md:hidden p-2 text-white/60 hover:text-white transition-colors"
          >
            {menuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile menu */}
      {menuOpen && (
        <div className="md:hidden bg-navy-900/98 backdrop-blur-xl border-b border-white/5 px-4 py-4 space-y-3">
          {NAV_LINKS.map(link => (
            <Link
              key={link.href}
              href={link.href}
              onClick={() => setMenuOpen(false)}
              className={cn(
                'block py-2 text-sm font-medium transition-colors',
                pathname === link.href ? 'text-electric-400' : 'text-white/60'
              )}
            >
              {link.label}
            </Link>
          ))}
          <div className="pt-2 border-t border-white/5 flex items-center gap-2">
            <select
              value={currency}
              onChange={e => setCurrency(e.target.value as any)}
              className="bg-navy-700/60 border border-white/10 text-white text-sm rounded-lg px-3 py-2 cursor-pointer focus:outline-none"
            >
              {CURRENCIES.map(c => (
                <option key={c.code} value={c.code}>{c.flag} {c.code}</option>
              ))}
            </select>
            {user ? (
              <div className="flex gap-2 flex-1">
                <Link href="/dashboard" onClick={() => setMenuOpen(false)} className="btn-secondary text-sm px-3 py-2 flex-1 text-center">
                  Dashboard
                </Link>
                <button onClick={handleSignOut} className="btn-secondary text-sm px-3 py-2 text-red-400 border-red-500/20">
                  <LogOut className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <div className="flex gap-2 flex-1">
                <Link href="/login" onClick={() => setMenuOpen(false)} className="btn-secondary text-sm px-3 py-2 flex-1 text-center">Sign In</Link>
                <Link href="/signup" onClick={() => setMenuOpen(false)} className="btn-primary text-sm px-3 py-2 flex-1 text-center">Sign Up</Link>
              </div>
            )}
          </div>
        </div>
      )}
    </nav>
  )
}
