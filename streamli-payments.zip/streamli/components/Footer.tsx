import Link from 'next/link'
import { Zap, Twitter, Github, Mail } from 'lucide-react'

export default function Footer() {
  return (
    <footer className="border-t border-white/5 bg-navy-900/50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="md:col-span-2 space-y-4">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-gradient-to-br from-electric-400 to-accent-500 rounded-lg flex items-center justify-center">
                <Zap className="w-4 h-4 text-white fill-white" />
              </div>
              <span className="font-display font-bold text-xl text-white">
                Stream<span className="gradient-text">LI</span>
              </span>
            </div>
            <p className="text-white/40 text-sm max-w-xs leading-relaxed">
              The fastest way to buy digital subscriptions and gaming gift cards. Instant delivery, secure payments.
            </p>
            <div className="flex items-center gap-3">
              <a href="#" className="p-2 bg-navy-700/50 rounded-lg text-white/40 hover:text-electric-400 hover:bg-navy-600/50 transition-colors border border-white/5">
                <Twitter className="w-4 h-4" />
              </a>
              <a href="#" className="p-2 bg-navy-700/50 rounded-lg text-white/40 hover:text-electric-400 hover:bg-navy-600/50 transition-colors border border-white/5">
                <Github className="w-4 h-4" />
              </a>
              <a href="mailto:support@streamli.com" className="p-2 bg-navy-700/50 rounded-lg text-white/40 hover:text-electric-400 hover:bg-navy-600/50 transition-colors border border-white/5">
                <Mail className="w-4 h-4" />
              </a>
            </div>
          </div>

          {/* Links */}
          <div>
            <h4 className="font-display font-semibold text-sm text-white/80 uppercase tracking-wider mb-4">Marketplace</h4>
            <ul className="space-y-2">
              {['Gaming', 'Streaming', 'AI Tools', 'Design Tools'].map(cat => (
                <li key={cat}>
                  <Link href={`/marketplace?category=${cat.toLowerCase().replace(' ', '-')}`}
                    className="text-sm text-white/40 hover:text-white transition-colors">
                    {cat}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Support */}
          <div>
            <h4 className="font-display font-semibold text-sm text-white/80 uppercase tracking-wider mb-4">Support</h4>
            <ul className="space-y-2">
              {[
                { label: 'My Orders', href: '/dashboard' },
                { label: 'Help Center', href: '#' },
                { label: 'Privacy Policy', href: '#' },
                { label: 'Terms of Service', href: '#' },
              ].map(link => (
                <li key={link.label}>
                  <Link href={link.href} className="text-sm text-white/40 hover:text-white transition-colors">
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="mt-12 pt-6 border-t border-white/5 flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-xs text-white/20">
            © {new Date().getFullYear()} StreamLI. All rights reserved.
          </p>
          <div className="flex items-center gap-4 text-xs text-white/20">
            <span>Secured by Stripe</span>
            <span className="text-white/10">•</span>
            <span>Powered by Supabase</span>
            <span className="text-white/10">•</span>
            <span>Deployed on Vercel</span>
          </div>
        </div>
      </div>
    </footer>
  )
}
