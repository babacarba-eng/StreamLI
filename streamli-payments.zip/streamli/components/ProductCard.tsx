'use client'

import { useState } from 'react'
import Image from 'next/image'
import { useRouter } from 'next/navigation'
import { ShoppingCart, Zap, Star } from 'lucide-react'
import { Product } from '@/types'
import { useCurrencyStore } from '@/hooks/useCurrency'
import { formatPrice, getBadgeColor, cn } from '@/lib/utils'
import toast from 'react-hot-toast'

interface ProductCardProps {
  product: Product
  onBuy?: (product: Product) => void
  loading?: boolean
}

export default function ProductCard({ product, onBuy, loading }: ProductCardProps) {
  const { currency } = useCurrencyStore()
  const [imgError, setImgError] = useState(false)
  const [buying, setBuying] = useState(false)
  const router = useRouter()

  const handleBuy = async () => {
    if (loading || buying) return
    setBuying(true)
    try {
      if (onBuy) {
        await onBuy(product)
      }
    } finally {
      setBuying(false)
    }
  }

  const CategoryIcon: Record<string, string> = {
    gaming: '🎮',
    streaming: '📺',
    'ai-tools': '🤖',
    'design-tools': '🎨',
  }

  return (
    <div className={cn(
      'card card-hover group relative flex flex-col overflow-hidden',
      'hover:scale-[1.02] transition-all duration-300'
    )}>
      {/* Glow effect on hover */}
      <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none">
        <div className="absolute inset-0 bg-gradient-to-b from-electric-500/5 to-transparent" />
      </div>

      {/* Badge */}
      {product.badge && (
        <div className="absolute top-3 right-3 z-10">
          <span className={cn('badge', getBadgeColor(product.badge))}>
            {product.badge === 'Hot' && '🔥 '}
            {product.badge === 'Trending' && '📈 '}
            {product.badge === 'New' && '✨ '}
            {product.badge === 'Popular' && '⭐ '}
            {product.badge}
          </span>
        </div>
      )}

      {/* Image area */}
      <div className="relative h-40 bg-navy-700/50 flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-electric-500/5 to-accent-500/5" />
        {!imgError ? (
          <div className="relative w-20 h-20 flex items-center justify-center">
            <img
              src={product.image_url}
              alt={product.name}
              className="max-w-full max-h-full object-contain drop-shadow-lg"
              onError={() => setImgError(true)}
            />
          </div>
        ) : (
          <div className="w-20 h-20 bg-navy-600 rounded-2xl flex items-center justify-center text-4xl">
            {CategoryIcon[product.category] || '📦'}
          </div>
        )}
        {/* Category chip */}
        <div className="absolute bottom-2 left-2">
          <span className="text-xs bg-navy-900/80 backdrop-blur-sm px-2 py-1 rounded-full text-white/50 border border-white/5">
            {CategoryIcon[product.category]} {product.category.replace('-', ' ')}
          </span>
        </div>
      </div>

      {/* Content */}
      <div className="flex flex-col flex-1 p-4 gap-3">
        <div className="flex-1">
          <h3 className="font-display font-semibold text-sm text-white line-clamp-1 group-hover:text-electric-400 transition-colors">
            {product.name}
          </h3>
          <p className="text-xs text-white/40 mt-1 line-clamp-2 leading-relaxed">
            {product.description}
          </p>
        </div>

        {/* Price + Buy */}
        <div className="flex items-center justify-between pt-2 border-t border-white/5">
          <div>
            <div className="font-display font-bold text-lg text-white">
              {formatPrice(product.price_usd, currency)}
            </div>
            {currency !== 'USD' && (
              <div className="text-xs text-white/30">
                ${product.price_usd.toFixed(2)} USD
              </div>
            )}
          </div>
          <button
            onClick={handleBuy}
            disabled={buying || loading}
            className={cn(
              'flex items-center gap-1.5 px-4 py-2 rounded-lg text-sm font-semibold transition-all duration-200',
              'bg-electric-500 hover:bg-electric-400 text-white shadow-glow-sm hover:shadow-glow',
              'hover:-translate-y-0.5 active:translate-y-0',
              'disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:translate-y-0'
            )}
          >
            {buying ? (
              <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
            ) : (
              <Zap className="w-3.5 h-3.5" />
            )}
            Buy Now
          </button>
        </div>
      </div>
    </div>
  )
}

// Skeleton loader
export function ProductCardSkeleton() {
  return (
    <div className="card overflow-hidden">
      <div className="h-40 shimmer" />
      <div className="p-4 space-y-3">
        <div className="h-4 rounded shimmer" />
        <div className="h-3 rounded shimmer w-3/4" />
        <div className="h-3 rounded shimmer w-1/2" />
        <div className="flex justify-between pt-2 border-t border-white/5">
          <div className="h-6 w-20 rounded shimmer" />
          <div className="h-8 w-24 rounded-lg shimmer" />
        </div>
      </div>
    </div>
  )
}
