import type { Metadata } from 'next'
import { Syne, Plus_Jakarta_Sans, JetBrains_Mono } from 'next/font/google'
import { Toaster } from 'react-hot-toast'
import './globals.css'

const syne = Syne({
  subsets: ['latin'],
  variable: '--font-syne',
  weight: ['400', '500', '600', '700', '800'],
})

const plusJakarta = Plus_Jakarta_Sans({
  subsets: ['latin'],
  variable: '--font-plus-jakarta',
  weight: ['300', '400', '500', '600', '700'],
})

const jetbrainsMono = JetBrains_Mono({
  subsets: ['latin'],
  variable: '--font-jetbrains',
  weight: ['400', '500'],
})

export const metadata: Metadata = {
  title: 'StreamLI — Digital Subscriptions & Gift Cards',
  description: 'Buy gaming gift cards and digital subscriptions instantly. PSN, Xbox, Steam, Spotify, Netflix and more.',
  keywords: 'gift cards, PSN, Xbox, Steam, Spotify, Netflix, digital subscriptions, gaming',
  openGraph: {
    title: 'StreamLI — Digital Subscriptions & Gift Cards',
    description: 'Buy gaming gift cards and digital subscriptions instantly.',
    type: 'website',
  },
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en" className="dark">
      <body className={`${syne.variable} ${plusJakarta.variable} ${jetbrainsMono.variable} font-body bg-navy-950 text-white antialiased`}>
        {children}
        <Toaster
          position="bottom-right"
          toastOptions={{
            style: {
              background: '#0a1930',
              color: '#fff',
              border: '1px solid rgba(14,165,233,0.2)',
            },
            success: {
              iconTheme: { primary: '#0ea5e9', secondary: '#fff' },
            },
          }}
        />
      </body>
    </html>
  )
}
