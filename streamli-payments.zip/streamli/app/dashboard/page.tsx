'use client'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { ShoppingBag, Copy, CheckCheck, Package, TrendingUp, Calendar, ExternalLink, LogOut } from 'lucide-react'
import Navbar from '@/components/Navbar'
import Footer from '@/components/Footer'
import { createBrowserClient } from '@/lib/supabase'
import { Order, Profile } from '@/types'
import { cn } from '@/lib/utils'
import toast from 'react-hot-toast'
import Link from 'next/link'

const STATUS_STYLES: Record<string, string> = {
  completed: 'bg-green-500/20 text-green-400 border-green-500/30',
  pending: 'bg-amber-500/20 text-amber-400 border-amber-500/30',
  failed: 'bg-red-500/20 text-red-400 border-red-500/30',
  refunded: 'bg-purple-500/20 text-purple-400 border-purple-500/30',
}

export default function DashboardPage() {
  const [user, setUser] = useState<any>(null)
  const [profile, setProfile] = useState<Profile | null>(null)
  const [orders, setOrders] = useState<(Order & { product: any })[]>([])
  const [loading, setLoading] = useState(true)
  const [copiedId, setCopiedId] = useState<string | null>(null)
  const router = useRouter()
  const supabase = createBrowserClient()

  useEffect(() => {
    const init = async () => {
      const { data: { session } } = await supabase.auth.getSession()
      if (!session) {
        router.push('/login')
        return
      }
      setUser(session.user)

      const [{ data: profileData }, { data: ordersData }] = await Promise.all([
        supabase.from('profiles').select('*').eq('id', session.user.id).single(),
        supabase
          .from('orders')
          .select('*, product:products(*)')
          .eq('user_id', session.user.id)
          .order('created_at', { ascending: false }),
      ])

      setProfile(profileData)
      setOrders(ordersData || [])
      setLoading(false)
    }
    init()
  }, [])

  const copyCode = (code: string, id: string) => {
    navigator.clipboard.writeText(code)
    setCopiedId(id)
    toast.success('Code copied to clipboard!')
    setTimeout(() => setCopiedId(null), 2000)
  }

  const handleSignOut = async () => {
    await supabase.auth.signOut()
    router.push('/')
  }

  const stats = {
    total: orders.length,
    completed: orders.filter(o => o.status === 'completed').length,
    totalSpent: orders
      .filter(o => o.status === 'completed')
      .reduce((sum, o) => sum + o.amount_usd, 0),
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-navy-950 flex items-center justify-center">
        <div className="text-center">
          <div className="w-8 h-8 border-2 border-electric-500/30 border-t-electric-500 rounded-full animate-spin mx-auto mb-4" />
          <p className="text-white/40 text-sm">Loading dashboard...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-navy-950">
      <Navbar />

      <div className="pt-24 pb-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-6xl mx-auto">
          {/* Header */}
          <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 mb-8">
            <div>
              <h1 className="font-display font-bold text-3xl md:text-4xl text-white mb-1">
                My Dashboard
              </h1>
              <p className="text-white/40">
                Welcome back, <span className="text-white">{profile?.full_name || user?.email}</span>
              </p>
            </div>
            <div className="flex items-center gap-3">
              <Link href="/marketplace" className="btn-primary">
                <ShoppingBag className="w-4 h-4" />
                Shop More
              </Link>
              <button onClick={handleSignOut} className="btn-secondary">
                <LogOut className="w-4 h-4" />
                Sign Out
              </button>
            </div>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-8">
            {[
              {
                label: 'Total Orders',
                value: stats.total,
                icon: <Package className="w-5 h-5" />,
                color: 'text-electric-400',
                bg: 'bg-electric-500/10',
              },
              {
                label: 'Completed',
                value: stats.completed,
                icon: <CheckCheck className="w-5 h-5" />,
                color: 'text-green-400',
                bg: 'bg-green-500/10',
              },
              {
                label: 'Total Spent',
                value: `$${stats.totalSpent.toFixed(2)}`,
                icon: <TrendingUp className="w-5 h-5" />,
                color: 'text-accent-400',
                bg: 'bg-accent-500/10',
              },
            ].map((s, i) => (
              <div key={i} className="card p-5 flex items-center gap-4">
                <div className={cn('w-12 h-12 rounded-xl flex items-center justify-center', s.bg, s.color)}>
                  {s.icon}
                </div>
                <div>
                  <div className="font-display font-bold text-2xl text-white">{s.value}</div>
                  <div className="text-white/40 text-sm">{s.label}</div>
                </div>
              </div>
            ))}
          </div>

          {/* Orders table */}
          <div className="card overflow-hidden">
            <div className="flex items-center justify-between px-6 py-4 border-b border-white/5">
              <h2 className="font-display font-semibold text-lg text-white">Order History</h2>
              <span className="text-white/30 text-sm">{orders.length} orders</span>
            </div>

            {orders.length === 0 ? (
              <div className="text-center py-16">
                <ShoppingBag className="w-10 h-10 text-white/20 mx-auto mb-3" />
                <h3 className="font-semibold text-white/40 mb-1">No orders yet</h3>
                <p className="text-white/20 text-sm mb-4">Start shopping to see your orders here</p>
                <Link href="/marketplace" className="btn-primary text-sm">
                  Browse Marketplace
                </Link>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full data-table">
                  <thead>
                    <tr className="border-b border-white/5">
                      <th>Product</th>
                      <th>Amount</th>
                      <th>Status</th>
                      <th>Code</th>
                      <th>Date</th>
                    </tr>
                  </thead>
                  <tbody>
                    {orders.map(order => (
                      <tr key={order.id}>
                        <td>
                          <div className="flex items-center gap-3">
                            {order.product?.image_url && (
                              <div className="w-8 h-8 bg-navy-700 rounded-lg flex items-center justify-center overflow-hidden flex-shrink-0">
                                <img
                                  src={order.product.image_url}
                                  alt={order.product.name}
                                  className="w-6 h-6 object-contain"
                                  onError={(e) => { e.currentTarget.style.display = 'none' }}
                                />
                              </div>
                            )}
                            <div>
                              <div className="font-medium text-white text-sm">
                                {order.product?.name || 'Unknown Product'}
                              </div>
                              <div className="text-white/30 text-xs">#{order.id.slice(0, 8)}</div>
                            </div>
                          </div>
                        </td>
                        <td>
                          <span className="font-mono text-white/80">
                            ${order.amount_usd.toFixed(2)}
                          </span>
                          <span className="text-white/30 text-xs ml-1">USD</span>
                        </td>
                        <td>
                          <span className={cn('badge', STATUS_STYLES[order.status] || STATUS_STYLES.pending)}>
                            {order.status}
                          </span>
                        </td>
                        <td>
                          {order.delivery_code && order.status === 'completed' ? (
                            <button
                              onClick={() => copyCode(order.delivery_code!, order.id)}
                              className="flex items-center gap-1.5 font-mono text-xs text-electric-400 hover:text-electric-300 bg-electric-500/10 hover:bg-electric-500/20 px-2 py-1 rounded-lg transition-all"
                            >
                              {copiedId === order.id ? (
                                <CheckCheck className="w-3 h-3" />
                              ) : (
                                <Copy className="w-3 h-3" />
                              )}
                              {order.delivery_code.substring(0, 8)}...
                            </button>
                          ) : (
                            <span className="text-white/20 text-xs">—</span>
                          )}
                        </td>
                        <td>
                          <div className="flex items-center gap-1 text-white/30 text-xs">
                            <Calendar className="w-3 h-3" />
                            {new Date(order.created_at).toLocaleDateString('en-US', {
                              day: '2-digit',
                              month: 'short',
                              year: 'numeric',
                            })}
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      </div>

      <Footer />
    </div>
  )
}
