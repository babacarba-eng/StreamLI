import Link from 'next/link'
import { ArrowRight, Zap, Shield, Clock, Globe, Star, ChevronRight, Gamepad2, Tv, Bot, Palette } from 'lucide-react'
import Navbar from '@/components/Navbar'
import Footer from '@/components/Footer'

const STATS = [
  { value: '50K+', label: 'Happy Customers' },
  { value: '13+', label: 'Digital Products' },
  { value: '99.9%', label: 'Uptime' },
  { value: '<1min', label: 'Delivery Time' },
]

const FEATURES = [
  {
    icon: <Zap className="w-5 h-5" />,
    title: 'Instant Delivery',
    desc: 'Get your codes and subscriptions within seconds of payment.',
  },
  {
    icon: <Shield className="w-5 h-5" />,
    title: 'Secure Payments',
    desc: 'Powered by Stripe — your payment data is always encrypted.',
  },
  {
    icon: <Globe className="w-5 h-5" />,
    title: 'Multi-Currency',
    desc: 'Pay in MAD or FCFA with prices updated in real-time.',
  },
  {
    icon: <Clock className="w-5 h-5" />,
    title: '24/7 Support',
    desc: 'Our team is always ready to help with any issues.',
  },
]

const CATEGORIES = [
  {
    id: 'gaming',
    icon: <Gamepad2 className="w-8 h-8" />,
    label: 'Gaming',
    desc: 'PSN, Xbox, Steam, Roblox & more',
    count: 6,
    color: 'from-blue-500/20 to-electric-500/20',
    borderColor: 'group-hover:border-blue-500/40',
  },
  {
    id: 'streaming',
    icon: <Tv className="w-8 h-8" />,
    label: 'Streaming',
    desc: 'Spotify, Netflix, Prime Video & more',
    count: 4,
    color: 'from-green-500/20 to-emerald-500/20',
    borderColor: 'group-hover:border-green-500/40',
  },
  {
    id: 'ai-tools',
    icon: <Bot className="w-8 h-8" />,
    label: 'AI Tools',
    desc: 'ChatGPT Plus and AI subscriptions',
    count: 1,
    color: 'from-purple-500/20 to-accent-500/20',
    borderColor: 'group-hover:border-purple-500/40',
  },
  {
    id: 'design-tools',
    icon: <Palette className="w-8 h-8" />,
    label: 'Design Tools',
    desc: 'Canva Pro, CapCut Pro & more',
    count: 2,
    color: 'from-orange-500/20 to-amber-500/20',
    borderColor: 'group-hover:border-orange-500/40',
  },
]

const TESTIMONIALS = [
  {
    name: 'Youssef B.',
    location: 'Casablanca, MA',
    text: 'Got my PSN card in 30 seconds. Paid in MAD which was perfect. Will definitely use again!',
    rating: 5,
  },
  {
    name: 'Amara K.',
    location: 'Dakar, SN',
    text: 'StreamLI is the only platform where I can buy Spotify Premium with CFA Francs. Love it.',
    rating: 5,
  },
  {
    name: 'Mehdi R.',
    location: 'Rabat, MA',
    text: 'ChatGPT Plus subscription arrived instantly. The price conversion to MAD is super helpful.',
    rating: 5,
  },
]

export default function LandingPage() {
  return (
    <div className="min-h-screen bg-navy-950 overflow-hidden">
      <Navbar />

      {/* Hero */}
      <section className="relative pt-32 pb-20 md:pt-40 md:pb-32 mesh-bg">
        {/* Grid pattern */}
        <div className="absolute inset-0 bg-grid-pattern opacity-30" />

        {/* Orbs */}
        <div className="absolute top-20 left-1/4 w-96 h-96 bg-electric-500/10 rounded-full blur-[100px] pointer-events-none" />
        <div className="absolute bottom-0 right-1/4 w-80 h-80 bg-accent-500/10 rounded-full blur-[100px] pointer-events-none" />

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          {/* Badge */}
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-electric-500/10 border border-electric-500/20 rounded-full text-electric-400 text-sm font-medium mb-8 animate-fade-in">
            <Zap className="w-3.5 h-3.5 fill-electric-400" />
            Instant digital delivery platform
            <span className="w-1.5 h-1.5 rounded-full bg-green-400 animate-pulse" />
          </div>

          <h1 className="font-display font-extrabold text-5xl md:text-7xl lg:text-8xl text-white mb-6 leading-[0.95] tracking-tight animate-slide-up">
            Buy Digital
            <br />
            <span className="gradient-text">Subscriptions</span>
            <br />
            Instantly
          </h1>

          <p className="text-white/50 text-lg md:text-xl max-w-2xl mx-auto mb-10 leading-relaxed animate-fade-in">
            The fastest marketplace for gaming gift cards and streaming subscriptions.
            Pay in <strong className="text-white/70">MAD</strong> or <strong className="text-white/70">FCFA</strong> — delivered in seconds.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 animate-slide-up">
            <Link href="/marketplace" className="btn-primary text-base px-8 py-4">
              Browse Marketplace
              <ArrowRight className="w-5 h-5" />
            </Link>
            <Link href="/signup" className="btn-outline text-base px-8 py-4">
              Create Free Account
            </Link>
          </div>

          {/* Trust bar */}
          <div className="mt-12 flex items-center justify-center gap-6 text-sm text-white/30 flex-wrap">
            <span className="flex items-center gap-1.5">
              <Shield className="w-4 h-4 text-green-500" />
              SSL Secured
            </span>
            <span className="text-white/10">|</span>
            <span className="flex items-center gap-1.5">
              <Zap className="w-4 h-4 text-electric-400" />
              Stripe Payments
            </span>
            <span className="text-white/10">|</span>
            <span className="flex items-center gap-1.5">
              <Clock className="w-4 h-4 text-accent-400" />
              Instant Delivery
            </span>
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="py-12 border-y border-white/5 bg-navy-900/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {STATS.map((stat, i) => (
              <div key={i} className="text-center">
                <div className="font-display font-black text-3xl md:text-4xl gradient-text">{stat.value}</div>
                <div className="text-white/40 text-sm mt-1">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Categories */}
      <section className="py-24 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="section-title mb-4">Browse by Category</h2>
            <p className="text-white/40 max-w-xl mx-auto">Everything from AAA gaming to creative tools, all in one place.</p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {CATEGORIES.map((cat) => (
              <Link
                key={cat.id}
                href={`/marketplace?category=${cat.id}`}
                className={`card card-hover group p-6 relative overflow-hidden ${cat.borderColor}`}
              >
                <div className={`absolute inset-0 bg-gradient-to-br ${cat.color} opacity-0 group-hover:opacity-100 transition-opacity duration-300`} />
                <div className="relative">
                  <div className="text-electric-400 mb-4 opacity-80 group-hover:opacity-100 transition-opacity">
                    {cat.icon}
                  </div>
                  <h3 className="font-display font-bold text-lg text-white mb-1">{cat.label}</h3>
                  <p className="text-white/40 text-sm mb-4">{cat.desc}</p>
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-white/30">{cat.count} products</span>
                    <ChevronRight className="w-4 h-4 text-white/30 group-hover:text-electric-400 group-hover:translate-x-1 transition-all" />
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-24 px-4 sm:px-6 lg:px-8 bg-navy-900/30">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="section-title mb-4">Why StreamLI?</h2>
            <p className="text-white/40 max-w-xl mx-auto">Built for Africa and beyond — fast, secure, and in your currency.</p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {FEATURES.map((f, i) => (
              <div key={i} className="card p-6 text-center group hover:border-electric-500/20 transition-all duration-300">
                <div className="w-12 h-12 bg-electric-500/10 rounded-xl flex items-center justify-center text-electric-400 mx-auto mb-4 group-hover:bg-electric-500/20 transition-colors">
                  {f.icon}
                </div>
                <h3 className="font-display font-semibold text-white mb-2">{f.title}</h3>
                <p className="text-white/40 text-sm leading-relaxed">{f.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Currency banner */}
      <section className="py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto">
          <div className="card glow-border p-8 md:p-12 text-center relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-radial from-electric-500/5 to-transparent" />
            <div className="relative">
              <div className="text-4xl mb-4">🇲🇦 🌍</div>
              <h2 className="font-display font-bold text-2xl md:text-3xl text-white mb-3">
                Pay in Your Currency
              </h2>
              <p className="text-white/50 mb-6 max-w-lg mx-auto">
                Switch between <span className="text-electric-400 font-semibold">Moroccan Dirham (MAD)</span> and{' '}
                <span className="text-accent-400 font-semibold">West African CFA Franc (FCFA)</span> at any time.
                Prices update automatically.
              </p>
              <Link href="/marketplace" className="btn-primary">
                Shop Now
                <ArrowRight className="w-4 h-4" />
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-24 px-4 sm:px-6 lg:px-8 bg-navy-900/30">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="section-title mb-4">Loved by Customers</h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {TESTIMONIALS.map((t, i) => (
              <div key={i} className="card p-6">
                <div className="flex items-center gap-0.5 mb-4">
                  {[...Array(t.rating)].map((_, j) => (
                    <Star key={j} className="w-4 h-4 text-amber-400 fill-amber-400" />
                  ))}
                </div>
                <p className="text-white/70 text-sm leading-relaxed mb-4">"{t.text}"</p>
                <div>
                  <div className="font-semibold text-white text-sm">{t.name}</div>
                  <div className="text-white/30 text-xs">{t.location}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-24 px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl mx-auto text-center">
          <h2 className="section-title mb-4">
            Ready to Get Started?
          </h2>
          <p className="text-white/40 mb-8">
            Join thousands of customers across Morocco and West Africa. Create your free account today.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <Link href="/signup" className="btn-primary text-lg px-10 py-4">
              Create Free Account
              <ArrowRight className="w-5 h-5" />
            </Link>
            <Link href="/marketplace" className="btn-secondary text-lg px-10 py-4">
              Browse Products
            </Link>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  )
}
