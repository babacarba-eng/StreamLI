'use client'

import { useState, useEffect, useCallback } from 'react'
import { useSearchParams, useRouter } from 'next/navigation'
import { Search, SlidersHorizontal } from 'lucide-react'
import Navbar from '@/components/Navbar'
import Footer from '@/components/Footer'
import ProductCard, { ProductCardSkeleton } from '@/components/ProductCard'
import CheckoutModal from '@/components/CheckoutModal'
import { createBrowserClient } from '@/lib/supabase'
import { Product, ProductCategory, CATEGORIES } from '@/types'
import { cn } from '@/lib/utils'
import toast from 'react-hot-toast'

export default function MarketplacePage() {
  const [products, setProducts] = useState<Product[]>([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [activeCategory, setActiveCategory] = useState<ProductCategory | 'all'>('all')
  const [checkoutProduct, setCheckoutProduct] = useState<Product | null>(null)
  const searchParams = useSearchParams()
  const router = useRouter()
  const supabase = createBrowserClient()

  useEffect(() => {
    const cat = searchParams.get('category') as ProductCategory | null
    if (cat) setActiveCategory(cat)
  }, [searchParams])

  useEffect(() => {
    fetchProducts()
  }, [])

  const fetchProducts = async () => {
    setLoading(true)
    const { data, error } = await supabase
      .from('products')
      .select('*')
      .eq('is_active', true)
      .order('created_at', { ascending: true })

    if (error) toast.error('Failed to load products')
    else setProducts(data || [])
    setLoading(false)
  }

  const handleBuy = useCallback(async (product: Product) => {
    const { data: { session } } = await supabase.auth.getSession()
    if (!session) {
      toast.error('Please sign in to purchase')
      router.push('/login')
      return
    }
    setCheckoutProduct(product)
  }, [router, supabase])

  const filtered = products.filter(p => {
    const matchCat = activeCategory === 'all' || p.category === activeCategory
    const matchSearch = p.name.toLowerCase().includes(search.toLowerCase()) ||
      p.description.toLowerCase().includes(search.toLowerCase())
    return matchCat && matchSearch
  })

  const handleCategoryChange = (cat: ProductCategory | 'all') => {
    setActiveCategory(cat)
    const params = new URLSearchParams(searchParams.toString())
    if (cat === 'all') params.delete('category')
    else params.set('category', cat)
    router.push(`/marketplace?${params.toString()}`)
  }

  return (
    <div className="min-h-screen bg-navy-950">
      <Navbar />

      <div className="pt-24 pb-8 px-4 sm:px-6 lg:px-8 border-b border-white/5 bg-navy-900/30 relative overflow-hidden">
        <div className="absolute inset-0 bg-grid-pattern opacity-20" />
        <div className="absolute top-0 right-0 w-96 h-64 bg-electric-500/5 rounded-full blur-[80px] pointer-events-none" />
        <div className="relative max-w-7xl mx-auto">
          <h1 className="font-display font-bold text-4xl md:text-5xl text-white mb-2">Marketplace</h1>
          <p className="text-white/40 text-lg">
            {loading ? '...' : `${products.length} products`} — instant delivery worldwide
          </p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex flex-col md:flex-row gap-4 mb-8">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-white/30" />
            <input type="text" placeholder="Search products..." value={search}
              onChange={e => setSearch(e.target.value)} className="input-field pl-10" />
          </div>
          <div className="flex items-center gap-2 overflow-x-auto pb-1">
            <button onClick={() => handleCategoryChange('all')}
              className={cn('flex items-center gap-1.5 px-4 py-2 rounded-xl text-sm font-medium whitespace-nowrap transition-all duration-200',
                activeCategory === 'all' ? 'bg-electric-500 text-white shadow-glow-sm' : 'bg-navy-700/50 text-white/50 hover:text-white border border-white/10')}>
              <SlidersHorizontal className="w-3.5 h-3.5" /> All
            </button>
            {CATEGORIES.map(cat => (
              <button key={cat.id} onClick={() => handleCategoryChange(cat.id)}
                className={cn('flex items-center gap-1.5 px-4 py-2 rounded-xl text-sm font-medium whitespace-nowrap transition-all duration-200',
                  activeCategory === cat.id ? 'bg-electric-500 text-white shadow-glow-sm' : 'bg-navy-700/50 text-white/50 hover:text-white border border-white/10')}>
                <span>{cat.icon}</span>{cat.label}
              </button>
            ))}
          </div>
        </div>

        {loading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
            {[...Array(8)].map((_, i) => <ProductCardSkeleton key={i} />)}
          </div>
        ) : filtered.length === 0 ? (
          <div className="text-center py-24">
            <div className="text-5xl mb-4">🔍</div>
            <h3 className="font-display font-bold text-xl text-white mb-2">No products found</h3>
            <p className="text-white/40">Try a different category or search term</p>
          </div>
        ) : activeCategory === 'all' ? (
          CATEGORIES.map(cat => {
            const catProducts = filtered.filter(p => p.category === cat.id)
            if (!catProducts.length) return null
            return (
              <div key={cat.id} className="mb-12">
                <div className="flex items-center gap-3 mb-5">
                  <span className="text-xl">{cat.icon}</span>
                  <h2 className="font-display font-bold text-xl text-white">{cat.label}</h2>
                  <span className="text-xs text-white/30 bg-navy-700/50 px-2.5 py-1 rounded-full border border-white/5">{catProducts.length} items</span>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
                  {catProducts.map(p => <ProductCard key={p.id} product={p} onBuy={handleBuy} />)}
                </div>
              </div>
            )
          })
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
            {filtered.map(p => <ProductCard key={p.id} product={p} onBuy={handleBuy} />)}
          </div>
        )}
      </div>

      <Footer />

      {/* Checkout Modal */}
      {checkoutProduct && (
        <CheckoutModal
          product={checkoutProduct}
          onClose={() => setCheckoutProduct(null)}
        />
      )}
    </div>
  )
}
