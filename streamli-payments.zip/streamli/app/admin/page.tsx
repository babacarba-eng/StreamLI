'use client'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import {
  LayoutDashboard, Package, ShoppingCart, Plus, Edit2, Trash2,
  Eye, EyeOff, X, Save, Users, DollarSign, CheckCircle2, XCircle,
  Clock, AlertTriangle, Banknote, RefreshCw, Copy, CheckCheck
} from 'lucide-react'
import Navbar from '@/components/Navbar'
import { createBrowserClient } from '@/lib/supabase'
import { Product, ProductCategory, CATEGORIES, PAYMENT_METHODS } from '@/types'
import { cn } from '@/lib/utils'
import toast from 'react-hot-toast'

type Tab = 'overview' | 'products' | 'orders' | 'cashplus'

interface ProductForm {
  name: string; description: string; price_usd: string
  category: ProductCategory; image_url: string; badge: string; is_active: boolean
}
const EMPTY_FORM: ProductForm = { name: '', description: '', price_usd: '', category: 'gaming', image_url: '', badge: '', is_active: true }

const STATUS_STYLE: Record<string, string> = {
  completed: 'bg-green-500/20 text-green-400 border-green-500/30',
  pending: 'bg-amber-500/20 text-amber-400 border-amber-500/30',
  awaiting_confirmation: 'bg-blue-500/20 text-blue-400 border-blue-500/30',
  failed: 'bg-red-500/20 text-red-400 border-red-500/30',
  refunded: 'bg-purple-500/20 text-purple-400 border-purple-500/30',
}

const PM_LABEL: Record<string, string> = {
  card: '💳 Card', paypal: '🅿️ PayPal',
  orange_money: '🟠 Orange Money', wave: '🌊 Wave', cashplus: '💵 CashPlus',
}

export default function AdminDashboard() {
  const [tab, setTab] = useState<Tab>('overview')
  const [loading, setLoading] = useState(true)
  const [products, setProducts] = useState<Product[]>([])
  const [orders, setOrders] = useState<any[]>([])
  const [showModal, setShowModal] = useState(false)
  const [editProduct, setEditProduct] = useState<Product | null>(null)
  const [form, setForm] = useState<ProductForm>(EMPTY_FORM)
  const [saving, setSaving] = useState(false)
  const [confirmingId, setConfirmingId] = useState<string | null>(null)
  const [copiedRef, setCopiedRef] = useState<string | null>(null)
  const router = useRouter()
  const supabase = createBrowserClient()

  useEffect(() => {
    const init = async () => {
      const { data: { session } } = await supabase.auth.getSession()
      if (!session) { router.push('/login'); return }
      const { data: profile } = await supabase.from('profiles').select('is_admin').eq('id', session.user.id).single()
      if (!profile?.is_admin) { router.push('/dashboard'); return }
      await Promise.all([fetchProducts(), fetchOrders()])
      setLoading(false)
    }
    init()
  }, [])

  const fetchProducts = async () => {
    const { data } = await supabase.from('products').select('*').order('created_at')
    setProducts(data || [])
  }

  const fetchOrders = async () => {
    const { data } = await supabase
      .from('orders')
      .select('*, product:products(name,image_url), profile:profiles(email,full_name)')
      .order('created_at', { ascending: false })
      .limit(200)
    setOrders(data || [])
  }

  const openAdd = () => { setEditProduct(null); setForm(EMPTY_FORM); setShowModal(true) }
  const openEdit = (p: Product) => {
    setEditProduct(p)
    setForm({ name: p.name, description: p.description, price_usd: String(p.price_usd), category: p.category as ProductCategory, image_url: p.image_url, badge: p.badge || '', is_active: p.is_active })
    setShowModal(true)
  }

  const handleSave = async () => {
    if (!form.name || !form.price_usd) { toast.error('Fill required fields'); return }
    setSaving(true)
    const payload = { name: form.name, description: form.description, price_usd: parseFloat(form.price_usd), category: form.category, image_url: form.image_url, badge: form.badge || null, is_active: form.is_active, updated_at: new Date().toISOString() }
    if (editProduct) {
      const { error } = await supabase.from('products').update(payload).eq('id', editProduct.id)
      if (error) toast.error(error.message)
      else { toast.success('Updated!'); setShowModal(false); fetchProducts() }
    } else {
      const { error } = await supabase.from('products').insert(payload)
      if (error) toast.error(error.message)
      else { toast.success('Product added!'); setShowModal(false); fetchProducts() }
    }
    setSaving(false)
  }

  const toggleActive = async (p: Product) => {
    await supabase.from('products').update({ is_active: !p.is_active }).eq('id', p.id)
    fetchProducts()
    toast.success(`${!p.is_active ? 'Activated' : 'Deactivated'}`)
  }

  const deleteProduct = async (id: string) => {
    if (!confirm('Delete this product?')) return
    await supabase.from('products').delete().eq('id', id)
    fetchProducts(); toast.success('Deleted')
  }

  const updateOrderStatus = async (id: string, status: string) => {
    await supabase.from('orders').update({ status }).eq('id', id)
    fetchOrders(); toast.success('Status updated')
  }

  const confirmCashPlus = async (orderId: string, action: 'confirm' | 'reject') => {
    setConfirmingId(orderId)
    try {
      const res = await fetch(`/api/admin/orders/${orderId}/confirm`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action }),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error)
      toast.success(action === 'confirm' ? `✅ Payment confirmed! Code: ${data.deliveryCode}` : '❌ Payment rejected')
      fetchOrders()
    } catch (err: any) {
      toast.error(err.message)
    } finally {
      setConfirmingId(null)
    }
  }

  const copyRef = (ref: string) => {
    navigator.clipboard.writeText(ref)
    setCopiedRef(ref)
    setTimeout(() => setCopiedRef(null), 1500)
  }

  if (loading) return (
    <div className="min-h-screen bg-navy-950 flex items-center justify-center">
      <div className="w-8 h-8 border-2 border-electric-500/30 border-t-electric-500 rounded-full animate-spin" />
    </div>
  )

  const cashplusPending = orders.filter(o => o.payment_method === 'cashplus' && o.status === 'awaiting_confirmation')
  const completedOrders = orders.filter(o => o.status === 'completed')
  const totalRevenue = completedOrders.reduce((s, o) => s + (o.amount_usd || 0), 0)
  const uniqueUsers = new Set(orders.map(o => o.user_id)).size

  return (
    <div className="min-h-screen bg-navy-950">
      <Navbar />
      <div className="pt-24 pb-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center justify-between mb-8">
            <div>
              <div className="flex items-center gap-2 text-accent-400 text-sm font-medium mb-1">
                <span className="w-2 h-2 rounded-full bg-accent-400 animate-pulse" />Admin Dashboard
              </div>
              <h1 className="font-display font-bold text-3xl md:text-4xl text-white">Control Center</h1>
            </div>
            <button onClick={fetchOrders} className="btn-secondary text-sm px-3 py-2">
              <RefreshCw className="w-4 h-4" /> Refresh
            </button>
          </div>

          {/* Tabs */}
          <div className="flex gap-2 mb-8 border-b border-white/5 pb-4 overflow-x-auto">
            {([
              { id: 'overview', label: 'Overview', icon: <LayoutDashboard className="w-4 h-4" /> },
              { id: 'products', label: 'Products', icon: <Package className="w-4 h-4" /> },
              { id: 'orders', label: 'All Orders', icon: <ShoppingCart className="w-4 h-4" /> },
              { id: 'cashplus', label: `CashPlus Pending`, icon: <Banknote className="w-4 h-4" />, alert: cashplusPending.length },
            ] as any[]).map(t => (
              <button key={t.id} onClick={() => setTab(t.id)}
                className={cn('flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium transition-all whitespace-nowrap',
                  tab === t.id ? 'bg-electric-500/20 text-electric-400 border border-electric-500/30' : 'text-white/40 hover:text-white hover:bg-white/5')}>
                {t.icon}{t.label}
                {t.alert > 0 && (
                  <span className="w-5 h-5 bg-amber-500 text-white text-xs font-bold rounded-full flex items-center justify-center">
                    {t.alert}
                  </span>
                )}
              </button>
            ))}
          </div>

          {/* ── Overview ── */}
          {tab === 'overview' && (
            <div className="space-y-6">
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                {[
                  { label: 'Total Revenue', value: `$${totalRevenue.toFixed(2)}`, icon: <DollarSign />, color: 'text-green-400', bg: 'bg-green-500/10' },
                  { label: 'Total Orders', value: orders.length, icon: <ShoppingCart />, color: 'text-electric-400', bg: 'bg-electric-500/10' },
                  { label: 'Active Products', value: products.filter(p => p.is_active).length, icon: <Package />, color: 'text-accent-400', bg: 'bg-accent-500/10' },
                  { label: 'Unique Customers', value: uniqueUsers, icon: <Users />, color: 'text-amber-400', bg: 'bg-amber-500/10' },
                ].map((s, i) => (
                  <div key={i} className="card p-5 flex items-center gap-4">
                    <div className={cn('w-12 h-12 rounded-xl flex items-center justify-center [&>svg]:w-5 [&>svg]:h-5', s.bg, s.color)}>{s.icon}</div>
                    <div>
                      <div className="font-display font-bold text-2xl text-white">{s.value}</div>
                      <div className="text-white/40 text-sm">{s.label}</div>
                    </div>
                  </div>
                ))}
              </div>

              {/* Payment method breakdown */}
              <div className="card p-5">
                <h3 className="font-display font-semibold text-white mb-4">Revenue by Payment Method</h3>
                <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
                  {(['card', 'paypal', 'orange_money', 'wave', 'cashplus'] as const).map(method => {
                    const methodOrders = completedOrders.filter(o => o.payment_method === method)
                    const rev = methodOrders.reduce((s: number, o: any) => s + (o.amount_usd || 0), 0)
                    return (
                      <div key={method} className="text-center p-3 bg-navy-800/40 rounded-xl border border-white/5">
                        <div className="text-2xl mb-1">{PAYMENT_METHODS.find(m => m.id === method)?.icon}</div>
                        <div className="font-bold text-white text-sm">${rev.toFixed(2)}</div>
                        <div className="text-white/30 text-xs mt-0.5">{methodOrders.length} orders</div>
                      </div>
                    )
                  })}
                </div>
              </div>

              {/* CashPlus alert */}
              {cashplusPending.length > 0 && (
                <div className="card border-amber-500/20 p-5">
                  <div className="flex items-center gap-3 mb-4">
                    <AlertTriangle className="w-5 h-5 text-amber-400" />
                    <h3 className="font-display font-semibold text-white">
                      {cashplusPending.length} CashPlus Payment{cashplusPending.length > 1 ? 's' : ''} Awaiting Confirmation
                    </h3>
                  </div>
                  <div className="space-y-2">
                    {cashplusPending.slice(0, 3).map((o: any) => (
                      <div key={o.id} className="flex items-center justify-between p-3 bg-navy-800/40 rounded-xl">
                        <div>
                          <div className="text-white text-sm font-medium">{o.product?.name}</div>
                          <div className="font-mono text-amber-400 text-xs mt-0.5">{o.cashplus_reference}</div>
                        </div>
                        <div className="flex gap-2">
                          <button onClick={() => confirmCashPlus(o.id, 'confirm')} disabled={confirmingId === o.id}
                            className="flex items-center gap-1.5 px-3 py-1.5 bg-green-500/20 hover:bg-green-500/30 text-green-400 text-xs font-semibold rounded-lg transition-colors disabled:opacity-50">
                            <CheckCircle2 className="w-3.5 h-3.5" /> Confirm
                          </button>
                          <button onClick={() => confirmCashPlus(o.id, 'reject')} disabled={confirmingId === o.id}
                            className="flex items-center gap-1.5 px-3 py-1.5 bg-red-500/20 hover:bg-red-500/30 text-red-400 text-xs font-semibold rounded-lg transition-colors disabled:opacity-50">
                            <XCircle className="w-3.5 h-3.5" /> Reject
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                  {cashplusPending.length > 3 && (
                    <button onClick={() => setTab('cashplus')} className="mt-3 text-xs text-electric-400 hover:text-electric-300 transition-colors">
                      View all {cashplusPending.length} pending →
                    </button>
                  )}
                </div>
              )}

              {/* Recent orders */}
              <div className="card overflow-hidden">
                <div className="px-6 py-4 border-b border-white/5">
                  <h3 className="font-display font-semibold text-white">Recent Orders</h3>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full data-table">
                    <thead><tr><th>Customer</th><th>Product</th><th>Method</th><th>Amount</th><th>Status</th><th>Date</th></tr></thead>
                    <tbody>
                      {orders.slice(0, 8).map(o => (
                        <tr key={o.id}>
                          <td className="text-white/70 text-xs">{o.profile?.email || '—'}</td>
                          <td className="text-white text-sm">{o.product?.name || '—'}</td>
                          <td className="text-white/50 text-xs">{PM_LABEL[o.payment_method] || o.payment_method}</td>
                          <td className="text-white font-mono">${o.amount_usd}</td>
                          <td><span className={cn('badge text-xs', STATUS_STYLE[o.status] || STATUS_STYLE.pending)}>{o.status}</span></td>
                          <td className="text-white/30 text-xs">{new Date(o.created_at).toLocaleDateString()}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* ── Products ── */}
          {tab === 'products' && (
            <div>
              <div className="flex items-center justify-between mb-5">
                <h2 className="font-display font-semibold text-xl text-white">Products <span className="text-white/30">({products.length})</span></h2>
                <button onClick={openAdd} className="btn-primary"><Plus className="w-4 h-4" />Add Product</button>
              </div>
              <div className="card overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full data-table">
                    <thead><tr><th>Product</th><th>Category</th><th>Price</th><th>Status</th><th>Actions</th></tr></thead>
                    <tbody>
                      {products.map(p => (
                        <tr key={p.id}>
                          <td>
                            <div className="flex items-center gap-3">
                              <div className="w-8 h-8 bg-navy-700 rounded-lg flex items-center justify-center overflow-hidden">
                                <img src={p.image_url} alt={p.name} className="w-6 h-6 object-contain" onError={e => { (e.target as HTMLImageElement).style.display = 'none' }} />
                              </div>
                              <div>
                                <div className="font-medium text-white text-sm">{p.name}</div>
                                {p.badge && <span className="text-xs text-electric-400">{p.badge}</span>}
                              </div>
                            </div>
                          </td>
                          <td><span className="text-white/50 text-xs capitalize">{p.category.replace('-', ' ')}</span></td>
                          <td><span className="font-mono text-white">${p.price_usd}</span></td>
                          <td>
                            <span className={cn('badge', p.is_active ? 'bg-green-500/20 text-green-400 border-green-500/30' : 'bg-red-500/20 text-red-400 border-red-500/30')}>
                              {p.is_active ? 'Active' : 'Inactive'}
                            </span>
                          </td>
                          <td>
                            <div className="flex items-center gap-2">
                              <button onClick={() => openEdit(p)} className="p-1.5 text-white/40 hover:text-electric-400 hover:bg-electric-500/10 rounded-lg transition-colors"><Edit2 className="w-4 h-4" /></button>
                              <button onClick={() => toggleActive(p)} className="p-1.5 text-white/40 hover:text-amber-400 hover:bg-amber-500/10 rounded-lg transition-colors">{p.is_active ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}</button>
                              <button onClick={() => deleteProduct(p.id)} className="p-1.5 text-white/40 hover:text-red-400 hover:bg-red-500/10 rounded-lg transition-colors"><Trash2 className="w-4 h-4" /></button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* ── All Orders ── */}
          {tab === 'orders' && (
            <div>
              <div className="flex items-center justify-between mb-5">
                <h2 className="font-display font-semibold text-xl text-white">All Orders <span className="text-white/30">({orders.length})</span></h2>
              </div>
              <div className="card overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full data-table">
                    <thead><tr><th>Order ID</th><th>Customer</th><th>Product</th><th>Method</th><th>Amount</th><th>Status</th><th>Date</th><th>Action</th></tr></thead>
                    <tbody>
                      {orders.map(o => (
                        <tr key={o.id}>
                          <td className="font-mono text-white/40 text-xs">#{o.id.slice(0, 8)}</td>
                          <td className="text-white/70 text-xs max-w-[120px] truncate">{o.profile?.email || '—'}</td>
                          <td className="text-white text-sm max-w-[140px] truncate">{o.product?.name || '—'}</td>
                          <td className="text-white/50 text-xs whitespace-nowrap">{PM_LABEL[o.payment_method] || '—'}</td>
                          <td className="font-mono text-white">${o.amount_usd}</td>
                          <td><span className={cn('badge text-xs', STATUS_STYLE[o.status] || STATUS_STYLE.pending)}>{o.status}</span></td>
                          <td className="text-white/30 text-xs">{new Date(o.created_at).toLocaleDateString()}</td>
                          <td>
                            <select value={o.status} onChange={e => updateOrderStatus(o.id, e.target.value)}
                              className="bg-navy-700/50 border border-white/10 text-white text-xs rounded px-2 py-1 focus:outline-none">
                              <option value="pending">Pending</option>
                              <option value="awaiting_confirmation">Awaiting</option>
                              <option value="completed">Completed</option>
                              <option value="failed">Failed</option>
                              <option value="refunded">Refunded</option>
                            </select>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* ── CashPlus Pending ── */}
          {tab === 'cashplus' && (
            <div>
              <div className="flex items-center gap-3 mb-6">
                <h2 className="font-display font-semibold text-xl text-white">
                  CashPlus — Manual Confirmations
                </h2>
                <span className={cn('badge', cashplusPending.length > 0 ? 'bg-amber-500/20 text-amber-400 border-amber-500/30' : 'bg-green-500/20 text-green-400 border-green-500/30')}>
                  {cashplusPending.length} pending
                </span>
              </div>

              {cashplusPending.length === 0 ? (
                <div className="card p-12 text-center">
                  <CheckCircle2 className="w-10 h-10 text-green-400 mx-auto mb-3 opacity-60" />
                  <h3 className="font-semibold text-white mb-1">All caught up!</h3>
                  <p className="text-white/40 text-sm">No CashPlus payments awaiting confirmation.</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {cashplusPending.map((o: any) => (
                    <div key={o.id} className="card border-amber-500/10 overflow-hidden">
                      <div className="flex flex-col md:flex-row md:items-center gap-4 p-5">
                        {/* Order info */}
                        <div className="flex items-center gap-3 flex-1 min-w-0">
                          <div className="w-10 h-10 bg-navy-700 rounded-xl flex items-center justify-center overflow-hidden flex-shrink-0">
                            <img src={o.product?.image_url} alt="" className="w-8 h-8 object-contain" onError={e => { (e.target as HTMLImageElement).style.display = 'none' }} />
                          </div>
                          <div className="min-w-0">
                            <div className="font-semibold text-white text-sm truncate">{o.product?.name}</div>
                            <div className="text-white/40 text-xs truncate">{o.profile?.email}</div>
                          </div>
                        </div>

                        {/* Reference + amount */}
                        <div className="flex items-center gap-4">
                          <div>
                            <div className="text-white/30 text-xs mb-1">Reference</div>
                            <button
                              onClick={() => copyRef(o.cashplus_reference)}
                              className="flex items-center gap-1.5 font-mono text-sm font-bold text-amber-300 hover:text-amber-200 transition-colors"
                            >
                              {o.cashplus_reference}
                              {copiedRef === o.cashplus_reference ? <CheckCheck className="w-3.5 h-3.5 text-green-400" /> : <Copy className="w-3.5 h-3.5 opacity-50" />}
                            </button>
                          </div>
                          <div>
                            <div className="text-white/30 text-xs mb-1">Amount</div>
                            <div className="font-display font-bold text-white">{o.amount_local?.toLocaleString()} MAD</div>
                          </div>
                          <div>
                            <div className="text-white/30 text-xs mb-1">Created</div>
                            <div className="text-white/60 text-xs flex items-center gap-1">
                              <Clock className="w-3 h-3" />
                              {new Date(o.created_at).toLocaleString('en-GB', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' })}
                            </div>
                          </div>
                        </div>

                        {/* Action buttons */}
                        <div className="flex gap-2 flex-shrink-0">
                          <button
                            onClick={() => confirmCashPlus(o.id, 'confirm')}
                            disabled={confirmingId === o.id}
                            className="flex items-center gap-2 px-4 py-2 bg-green-500/20 hover:bg-green-500/30 text-green-400 font-semibold rounded-xl text-sm transition-all border border-green-500/20 disabled:opacity-50"
                          >
                            {confirmingId === o.id ? (
                              <div className="w-4 h-4 border-2 border-green-400/30 border-t-green-400 rounded-full animate-spin" />
                            ) : (
                              <CheckCircle2 className="w-4 h-4" />
                            )}
                            Confirm Paid
                          </button>
                          <button
                            onClick={() => confirmCashPlus(o.id, 'reject')}
                            disabled={confirmingId === o.id}
                            className="flex items-center gap-2 px-4 py-2 bg-red-500/10 hover:bg-red-500/20 text-red-400 font-semibold rounded-xl text-sm transition-all border border-red-500/20 disabled:opacity-50"
                          >
                            <XCircle className="w-4 h-4" /> Reject
                          </button>
                        </div>
                      </div>

                      {/* Instructions reminder */}
                      <div className="px-5 pb-4">
                        <div className="p-3 bg-amber-500/5 border border-amber-500/10 rounded-xl text-xs text-white/40">
                          <strong className="text-amber-400">To confirm:</strong> Verify that {o.profile?.email} has paid{' '}
                          <strong className="text-white">{o.amount_local?.toLocaleString()} MAD</strong> at a CashPlus agent with reference{' '}
                          <strong className="text-amber-300 font-mono">{o.cashplus_reference}</strong>, then click "Confirm Paid" to release the delivery code.
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Product Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="card w-full max-w-lg max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between p-6 border-b border-white/5">
              <h3 className="font-display font-bold text-xl text-white">{editProduct ? 'Edit Product' : 'Add Product'}</h3>
              <button onClick={() => setShowModal(false)} className="text-white/40 hover:text-white"><X className="w-5 h-5" /></button>
            </div>
            <div className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-medium text-white/70 mb-2">Name *</label>
                <input value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} className="input-field" placeholder="Product name" />
              </div>
              <div>
                <label className="block text-sm font-medium text-white/70 mb-2">Description</label>
                <textarea value={form.description} onChange={e => setForm(f => ({ ...f, description: e.target.value }))} rows={2} className="input-field resize-none" />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-white/70 mb-2">Price (USD) *</label>
                  <input type="number" step="0.01" value={form.price_usd} onChange={e => setForm(f => ({ ...f, price_usd: e.target.value }))} className="input-field" placeholder="9.99" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-white/70 mb-2">Category *</label>
                  <select value={form.category} onChange={e => setForm(f => ({ ...f, category: e.target.value as ProductCategory }))} className="input-field">
                    {CATEGORIES.map(c => <option key={c.id} value={c.id}>{c.icon} {c.label}</option>)}
                  </select>
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-white/70 mb-2">Image URL</label>
                <input value={form.image_url} onChange={e => setForm(f => ({ ...f, image_url: e.target.value }))} className="input-field" placeholder="https://..." />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-white/70 mb-2">Badge</label>
                  <select value={form.badge} onChange={e => setForm(f => ({ ...f, badge: e.target.value }))} className="input-field">
                    <option value="">None</option>
                    <option value="Popular">⭐ Popular</option>
                    <option value="Hot">🔥 Hot</option>
                    <option value="New">✨ New</option>
                    <option value="Trending">📈 Trending</option>
                  </select>
                </div>
                <div className="flex items-end pb-1">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input type="checkbox" checked={form.is_active} onChange={e => setForm(f => ({ ...f, is_active: e.target.checked }))} className="w-4 h-4 accent-electric-500" />
                    <span className="text-sm text-white/70">Active</span>
                  </label>
                </div>
              </div>
            </div>
            <div className="flex gap-3 p-6 border-t border-white/5">
              <button onClick={() => setShowModal(false)} className="btn-secondary flex-1">Cancel</button>
              <button onClick={handleSave} disabled={saving} className="btn-primary flex-1">
                {saving ? <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" /> : <><Save className="w-4 h-4" />Save</>}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
