import { NextRequest, NextResponse } from 'next/server'
import { createAdminClient } from '@/lib/supabase'
import { createServerComponentClient } from '@supabase/auth-helpers-nextjs'
import { cookies } from 'next/headers'
import { verifyCashPlusReference } from '@/lib/cashplus'
import { generateDeliveryCode } from '@/lib/utils'

/** Admin endpoint to manually confirm or reject a CashPlus order */
export async function POST(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    // Only admins can call this
    const supabaseAuth = createServerComponentClient({ cookies })
    const { data: { session } } = await supabaseAuth.auth.getSession()
    if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

    const supabase = createAdminClient()
    const { data: profile } = await supabase
      .from('profiles')
      .select('is_admin')
      .eq('id', session.user.id)
      .single()

    if (!profile?.is_admin) {
      return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
    }

    const { action, note } = await req.json() // action: 'confirm' | 'reject'
    const orderId = params.id

    const { data: order, error: orderError } = await supabase
      .from('orders')
      .select('*, product:products(name)')
      .eq('id', orderId)
      .single()

    if (orderError || !order) {
      return NextResponse.json({ error: 'Order not found' }, { status: 404 })
    }

    if (order.payment_method !== 'cashplus') {
      return NextResponse.json({ error: 'Not a CashPlus order' }, { status: 400 })
    }

    if (order.status === 'completed') {
      return NextResponse.json({ error: 'Order already completed' }, { status: 400 })
    }

    if (action === 'confirm') {
      // Verify the reference is valid for this order
      if (order.cashplus_reference) {
        const valid = verifyCashPlusReference(orderId, order.cashplus_reference)
        if (!valid) {
          return NextResponse.json({ error: 'Reference mismatch' }, { status: 400 })
        }
      }

      const deliveryCode = generateDeliveryCode()

      await supabase
        .from('orders')
        .update({
          status: 'completed',
          delivery_code: deliveryCode,
        })
        .eq('id', orderId)

      return NextResponse.json({
        success: true,
        message: 'CashPlus payment confirmed',
        deliveryCode,
      })
    } else if (action === 'reject') {
      await supabase
        .from('orders')
        .update({ status: 'failed' })
        .eq('id', orderId)

      return NextResponse.json({
        success: true,
        message: 'CashPlus payment rejected',
      })
    } else {
      return NextResponse.json({ error: 'Invalid action. Use confirm or reject' }, { status: 400 })
    }
  } catch (err: any) {
    console.error('CashPlus confirm error:', err)
    return NextResponse.json({ error: err.message }, { status: 500 })
  }
}
