import { NextRequest, NextResponse } from 'next/server'
import { createAdminClient } from '@/lib/supabase'
import { parseWebhookPayload, verifyPayment } from '@/lib/orange-money'
import { generateDeliveryCode } from '@/lib/utils'

/**
 * Orange Money Webhook Handler
 * Orange POSTs to this endpoint when payment status changes.
 * Expected payload (form-encoded or JSON depending on OM version):
 *   status, order_id, pay_token, amount, txnid, message
 */
export async function POST(req: NextRequest) {
  try {
    let body: Record<string, any>

    const contentType = req.headers.get('content-type') || ''
    if (contentType.includes('application/json')) {
      body = await req.json()
    } else {
      // form-encoded
      const text = await req.text()
      body = Object.fromEntries(new URLSearchParams(text))
    }

    const payload = parseWebhookPayload(body)

    console.log('[OM Webhook]', payload.status, payload.orderId, payload.txnId)

    const supabase = createAdminClient()

    // Find order by Orange Money pay_token or order_id
    const { data: order, error } = await supabase
      .from('orders')
      .select('*')
      .or(`id.eq.${payload.orderId},orange_money_pay_token.eq.${payload.payToken}`)
      .single()

    if (error || !order) {
      console.error('[OM Webhook] Order not found:', payload.orderId, payload.payToken)
      // Return 200 so Orange doesn't retry forever
      return NextResponse.json({ received: true })
    }

    // Server-side verification — don't trust webhook payload alone
    let verified = false
    try {
      const status = await verifyPayment(payload.payToken)
      verified = status.status === 'SUCCESSFULL'
    } catch (e) {
      console.error('[OM Webhook] Verification failed:', e)
    }

    if (payload.status === 'SUCCESS' && verified) {
      const deliveryCode = generateDeliveryCode()
      await supabase
        .from('orders')
        .update({ status: 'completed', delivery_code: deliveryCode })
        .eq('id', order.id)

      console.log(`[OM Webhook] Order ${order.id} completed. Delivery: ${deliveryCode}`)
    } else if (['FAILED', 'CANCELLED', 'EXPIRED'].includes(payload.status)) {
      await supabase.from('orders').update({ status: 'failed' }).eq('id', order.id)
      console.log(`[OM Webhook] Order ${order.id} failed: ${payload.status}`)
    }

    return NextResponse.json({ received: true })
  } catch (err: any) {
    console.error('[OM Webhook] Error:', err)
    // Still return 200 to prevent retries for unrecoverable errors
    return NextResponse.json({ received: true })
  }
}
