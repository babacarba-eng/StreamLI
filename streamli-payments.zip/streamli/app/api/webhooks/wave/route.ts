import { NextRequest, NextResponse } from 'next/server'
import { createAdminClient } from '@/lib/supabase'
import { validateWebhookSignature, parseWebhookPayload, getCheckoutSession } from '@/lib/wave'
import { generateDeliveryCode } from '@/lib/utils'

/**
 * Wave Webhook Handler
 * Wave POSTs to this URL when a checkout session status changes.
 * Header: Wave-Signature: t=<timestamp>,v1=<hmac-sha256>
 */
export async function POST(req: NextRequest) {
  const rawBody = await req.text()
  const signatureHeader = req.headers.get('wave-signature') || ''

  // ── Signature verification ─────────────────────────────────────────
  if (process.env.NODE_ENV !== 'development') {
    if (!signatureHeader || !validateWebhookSignature(rawBody, signatureHeader)) {
      console.error('[Wave Webhook] Invalid signature')
      return NextResponse.json({ error: 'Invalid signature' }, { status: 401 })
    }
  }

  try {
    const payload = parseWebhookPayload(JSON.parse(rawBody))
    const sessionId = payload.data.id
    const clientRef = payload.data.client_reference

    console.log('[Wave Webhook]', payload.type, sessionId, clientRef)

    const supabase = createAdminClient()

    // Find order by Wave session ID or client_reference (which is our order ID)
    const { data: order, error } = await supabase
      .from('orders')
      .select('*')
      .or(`wave_checkout_id.eq.${sessionId},id.eq.${clientRef}`)
      .single()

    if (error || !order) {
      console.error('[Wave Webhook] Order not found:', sessionId, clientRef)
      return NextResponse.json({ received: true })
    }

    // Server-side verify
    let serverStatus = payload.data.checkout_status
    try {
      const session = await getCheckoutSession(sessionId)
      serverStatus = session.checkoutStatus
    } catch (e) {
      console.error('[Wave Webhook] Session verify failed, using payload status')
    }

    switch (payload.type) {
      case 'checkout.session.completed':
        if (serverStatus === 'succeeded') {
          const deliveryCode = generateDeliveryCode()
          await supabase
            .from('orders')
            .update({ status: 'completed', delivery_code: deliveryCode })
            .eq('id', order.id)
          console.log(`[Wave Webhook] Order ${order.id} completed`)
        }
        break

      case 'checkout.session.failed':
      case 'checkout.session.expired':
        await supabase.from('orders').update({ status: 'failed' }).eq('id', order.id)
        console.log(`[Wave Webhook] Order ${order.id} failed/expired`)
        break
    }

    return NextResponse.json({ received: true })
  } catch (err: any) {
    console.error('[Wave Webhook] Error:', err)
    return NextResponse.json({ received: true })
  }
}
