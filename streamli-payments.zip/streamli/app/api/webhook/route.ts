import { NextRequest, NextResponse } from 'next/server'
import { stripe } from '@/lib/stripe'
import { createAdminClient } from '@/lib/supabase'
import { generateDeliveryCode } from '@/lib/utils'
import Stripe from 'stripe'

export async function POST(req: NextRequest) {
  const body = await req.text()
  const sig = req.headers.get('stripe-signature')!
  const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET!

  let event: Stripe.Event

  try {
    event = stripe.webhooks.constructEvent(body, sig, webhookSecret)
  } catch (err: any) {
    console.error('Webhook signature failed:', err.message)
    return NextResponse.json({ error: 'Invalid signature' }, { status: 400 })
  }

  const supabase = createAdminClient()

  switch (event.type) {
    case 'checkout.session.completed': {
      const session = event.data.object as Stripe.CheckoutSession

      if (session.payment_status === 'paid') {
        const { product_id, user_id, currency, amount_local, amount_usd } = session.metadata!

        // Generate delivery code (in production: fetch real code from provider API)
        const deliveryCode = generateDeliveryCode()

        // Update order status
        const { error } = await supabase
          .from('orders')
          .update({
            status: 'completed',
            delivery_code: deliveryCode,
          })
          .eq('stripe_session_id', session.id)

        if (error) {
          console.error('Failed to update order:', error)
        } else {
          console.log(`Order completed for session ${session.id}`)
        }
      }
      break
    }

    case 'checkout.session.expired':
    case 'payment_intent.payment_failed': {
      const sessionOrIntent = event.data.object as any
      const sessionId = sessionOrIntent.id || sessionOrIntent.latest_charge

      await supabase
        .from('orders')
        .update({ status: 'failed' })
        .eq('stripe_session_id', sessionId)

      break
    }

    case 'charge.refunded': {
      const charge = event.data.object as Stripe.Charge
      const paymentIntentId = charge.payment_intent as string

      // Find session by looking up the payment intent
      const sessions = await stripe.checkout.sessions.list({
        payment_intent: paymentIntentId,
      })

      if (sessions.data.length > 0) {
        await supabase
          .from('orders')
          .update({ status: 'refunded' })
          .eq('stripe_session_id', sessions.data[0].id)
      }
      break
    }

    default:
      console.log(`Unhandled event type: ${event.type}`)
  }

  return NextResponse.json({ received: true })
}

// Required for raw body parsing (Stripe signature verification)
export const config = {
  api: {
    bodyParser: false,
  },
}
