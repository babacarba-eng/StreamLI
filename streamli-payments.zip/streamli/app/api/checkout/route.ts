import { NextRequest, NextResponse } from 'next/server'
import { stripe } from '@/lib/stripe'
import { createAdminClient } from '@/lib/supabase'
import { createServerComponentClient } from '@supabase/auth-helpers-nextjs'
import { cookies } from 'next/headers'
import { CURRENCIES, Currency, PaymentMethod } from '@/types'
import { initiatePayment as omInitiate } from '@/lib/orange-money'
import { createCheckoutSession as waveCreate } from '@/lib/wave'
import { buildPaymentInfo } from '@/lib/cashplus'

const APP_URL = process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000'

export async function POST(req: NextRequest) {
  try {
    const { productId, currency = 'MAD', paymentMethod = 'card', customerPhone } = await req.json()

    const supabaseAuth = createServerComponentClient({ cookies })
    const { data: { session } } = await supabaseAuth.auth.getSession()
    if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

    const supabase = createAdminClient()
    const { data: product, error: productError } = await supabase
      .from('products')
      .select('*')
      .eq('id', productId)
      .eq('is_active', true)
      .single()

    if (productError || !product) {
      return NextResponse.json({ error: 'Product not found' }, { status: 404 })
    }

    const currencyConfig = CURRENCIES.find(c => c.code === currency)!
    const amountLocal = Math.round(product.price_usd * currencyConfig.rate)

    const baseOrder = {
      user_id: session.user.id,
      product_id: product.id,
      amount_usd: product.price_usd,
      currency,
      amount_local: amountLocal,
      payment_method: paymentMethod,
      status: 'pending',
    }

    switch (paymentMethod as PaymentMethod) {
      case 'card': {
        const stripeSession = await stripe.checkout.sessions.create({
          payment_method_types: ['card'],
          mode: 'payment',
          line_items: [{
            price_data: {
              currency: 'usd',
              product_data: {
                name: product.name,
                description: product.description,
                images: product.image_url ? [product.image_url] : undefined,
              },
              unit_amount: Math.round(product.price_usd * 100),
            },
            quantity: 1,
          }],
          metadata: { product_id: product.id, user_id: session.user.id, currency, amount_local: amountLocal.toString() },
          customer_email: session.user.email,
          success_url: `${APP_URL}/dashboard?success=true&session_id={CHECKOUT_SESSION_ID}`,
          cancel_url: `${APP_URL}/marketplace?canceled=true`,
          allow_promotion_codes: true,
        })
        await supabase.from('orders').insert({ ...baseOrder, stripe_session_id: stripeSession.id })
        return NextResponse.json({ url: stripeSession.url, method: 'redirect' })
      }

      case 'paypal': {
        const stripeSession = await stripe.checkout.sessions.create({
          payment_method_types: ['paypal'],
          mode: 'payment',
          line_items: [{
            price_data: {
              currency: 'usd',
              product_data: {
                name: product.name,
                description: product.description,
                images: product.image_url ? [product.image_url] : undefined,
              },
              unit_amount: Math.round(product.price_usd * 100),
            },
            quantity: 1,
          }],
          metadata: { product_id: product.id, user_id: session.user.id, currency, amount_local: amountLocal.toString() },
          customer_email: session.user.email,
          success_url: `${APP_URL}/dashboard?success=true&session_id={CHECKOUT_SESSION_ID}`,
          cancel_url: `${APP_URL}/marketplace?canceled=true`,
        })
        await supabase.from('orders').insert({ ...baseOrder, stripe_session_id: stripeSession.id })
        return NextResponse.json({ url: stripeSession.url, method: 'redirect' })
      }

      case 'orange_money': {
        const { data: orderRow } = await supabase.from('orders').insert({ ...baseOrder }).select().single()
        const omResult = await omInitiate({
          orderId: orderRow.id,
          amountFcfa: amountLocal,
          customerPhone: customerPhone || '',
          productName: product.name,
          returnUrl: `${APP_URL}/dashboard?success=true`,
          cancelUrl: `${APP_URL}/marketplace?canceled=true`,
          notifUrl: `${APP_URL}/api/webhooks/orange-money`,
        })
        await supabase.from('orders').update({ orange_money_pay_token: omResult.payToken, payment_reference: omResult.payToken }).eq('id', orderRow.id)
        return NextResponse.json({ method: 'redirect', url: omResult.paymentUrl, orderId: orderRow.id })
      }

      case 'wave': {
        const { data: orderRow } = await supabase.from('orders').insert({ ...baseOrder }).select().single()
        const waveSession = await waveCreate({
          orderId: orderRow.id,
          amountFcfa: amountLocal,
          currency: 'XOF',
          productName: product.name,
          clientReference: orderRow.id,
          successUrl: `${APP_URL}/dashboard?success=true`,
          errorUrl: `${APP_URL}/marketplace?canceled=true`,
        })
        await supabase.from('orders').update({ wave_checkout_id: waveSession.id, payment_reference: waveSession.id }).eq('id', orderRow.id)
        return NextResponse.json({ method: 'redirect', url: waveSession.wavelaunchUrl, sessionId: waveSession.id, expiresAt: waveSession.expiresAt, orderId: orderRow.id })
      }

      case 'cashplus': {
        const { data: orderRow } = await supabase.from('orders').insert({ ...baseOrder, status: 'awaiting_confirmation' }).select().single()
        const info = buildPaymentInfo(orderRow.id, amountLocal)
        await supabase.from('orders').update({ cashplus_reference: info.reference, payment_reference: info.reference }).eq('id', orderRow.id)
        return NextResponse.json({ method: 'cashplus', orderId: orderRow.id, reference: info.reference, amountMad: info.amountMad, expiresAt: info.expiresAt, instructions: info.instructions, agentLocatorUrl: info.agentLocatorUrl })
      }

      default:
        return NextResponse.json({ error: 'Unsupported payment method' }, { status: 400 })
    }
  } catch (err: any) {
    console.error('Checkout error:', err)
    return NextResponse.json({ error: err.message || 'Internal server error' }, { status: 500 })
  }
}
