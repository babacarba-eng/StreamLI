export type Currency = 'MAD' | 'FCFA' | 'USD'

export interface Product {
  id: string
  name: string
  description: string
  price_usd: number
  category: ProductCategory
  image_url: string
  badge?: string
  is_active: boolean
  created_at: string
  updated_at: string
}

export type ProductCategory = 'gaming' | 'streaming' | 'ai-tools' | 'design-tools'

export interface Order {
  id: string
  user_id: string
  product_id: string
  product?: Product
  amount_usd: number
  currency: string
  amount_local: number
  status: OrderStatus
  stripe_session_id: string
  delivery_code?: string
  created_at: string
  user_email?: string
}

export type OrderStatus = 'pending' | 'completed' | 'failed' | 'refunded'

export interface Profile {
  id: string
  email: string
  full_name?: string
  avatar_url?: string
  is_admin: boolean
  created_at: string
}

export interface CurrencyConfig {
  code: Currency
  symbol: string
  label: string
  rate: number // rate vs USD
  flag: string
}

export const CURRENCIES: CurrencyConfig[] = [
  { code: 'USD', symbol: '$', label: 'US Dollar', rate: 1, flag: '🇺🇸' },
  { code: 'MAD', symbol: 'MAD', label: 'Moroccan Dirham', rate: 10.05, flag: '🇲🇦' },
  { code: 'FCFA', symbol: 'FCFA', label: 'CFA Franc', rate: 612, flag: '🌍' },
]

export const CATEGORIES: { id: ProductCategory; label: string; icon: string }[] = [
  { id: 'gaming', label: 'Gaming', icon: '🎮' },
  { id: 'streaming', label: 'Streaming', icon: '📺' },
  { id: 'ai-tools', label: 'AI Tools', icon: '🤖' },
  { id: 'design-tools', label: 'Design Tools', icon: '🎨' },
]

export const PRODUCTS_DATA: Omit<Product, 'id' | 'created_at' | 'updated_at' | 'is_active'>[] = [
  // Gaming
  {
    name: 'PlayStation Network $10',
    description: 'Add $10 to your PSN wallet. Works on PS4, PS5, and PlayStation Store.',
    price_usd: 10,
    category: 'gaming',
    image_url: 'https://upload.wikimedia.org/wikipedia/commons/thumb/4/4e/Playstation_logo_colour.svg/200px-Playstation_logo_colour.svg.png',
    badge: 'Popular',
  },
  {
    name: 'Xbox Gift Card $15',
    description: 'Microsoft Xbox $15 gift card for games, DLC, and Xbox Game Pass.',
    price_usd: 15,
    category: 'gaming',
    image_url: 'https://upload.wikimedia.org/wikipedia/commons/thumb/f/f9/Xbox_one_logo.svg/200px-Xbox_one_logo.svg.png',
    badge: 'Hot',
  },
  {
    name: 'Nintendo eShop $20',
    description: '$20 Nintendo eShop card for Switch games and content.',
    price_usd: 20,
    category: 'gaming',
    image_url: 'https://upload.wikimedia.org/wikipedia/commons/thumb/0/0d/Nintendo.svg/200px-Nintendo.svg.png',
  },
  {
    name: 'Steam Wallet $20',
    description: 'Add $20 to your Steam wallet. Use for any game or DLC.',
    price_usd: 20,
    category: 'gaming',
    image_url: 'https://upload.wikimedia.org/wikipedia/commons/thumb/8/83/Steam_icon_logo.svg/200px-Steam_icon_logo.svg.png',
  },
  {
    name: 'Roblox Gift Card $25',
    description: '2000 Robux or 1-month Roblox Premium. For all platforms.',
    price_usd: 25,
    category: 'gaming',
    image_url: 'https://upload.wikimedia.org/wikipedia/commons/thumb/3/3a/Roblox_player_icon_black.svg/200px-Roblox_player_icon_black.svg.png',
    badge: 'New',
  },
  {
    name: 'V-Bucks 2800',
    description: '2800 Fortnite V-Bucks for cosmetics, Battle Pass and more.',
    price_usd: 20,
    category: 'gaming',
    image_url: 'https://upload.wikimedia.org/wikipedia/commons/thumb/8/82/Fortnite_F_lettermark_logo.png/200px-Fortnite_F_lettermark_logo.png',
  },
  // Streaming
  {
    name: 'Spotify Premium 1 Month',
    description: 'Ad-free music, offline listening, unlimited skips.',
    price_usd: 9.99,
    category: 'streaming',
    image_url: 'https://upload.wikimedia.org/wikipedia/commons/thumb/1/19/Spotify_logo_without_text.svg/200px-Spotify_logo_without_text.svg.png',
    badge: 'Popular',
  },
  {
    name: 'Apple Music 1 Month',
    description: '100M+ songs, spatial audio, lyrics, and more.',
    price_usd: 10.99,
    category: 'streaming',
    image_url: 'https://upload.wikimedia.org/wikipedia/commons/thumb/5/5f/Apple_Music_icon.svg/200px-Apple_Music_icon.svg.png',
  },
  {
    name: 'Netflix Standard 1 Month',
    description: 'Stream in Full HD on 2 screens simultaneously.',
    price_usd: 15.49,
    category: 'streaming',
    image_url: 'https://upload.wikimedia.org/wikipedia/commons/thumb/0/08/Netflix_2015_logo.svg/200px-Netflix_2015_logo.svg.png',
    badge: 'Hot',
  },
  {
    name: 'Prime Video 1 Month',
    description: 'Amazon original series, movies, and exclusive content.',
    price_usd: 8.99,
    category: 'streaming',
    image_url: 'https://upload.wikimedia.org/wikipedia/commons/thumb/1/11/Amazon_Prime_Video_logo.svg/200px-Amazon_Prime_Video_logo.svg.png',
  },
  // AI Tools
  {
    name: 'ChatGPT Plus 1 Month',
    description: 'GPT-4, DALL-E 3, faster responses and priority access.',
    price_usd: 20,
    category: 'ai-tools',
    image_url: 'https://upload.wikimedia.org/wikipedia/commons/thumb/0/04/ChatGPT_logo.svg/200px-ChatGPT_logo.svg.png',
    badge: 'Trending',
  },
  // Design Tools
  {
    name: 'Canva Pro 1 Month',
    description: 'Premium templates, Brand Kit, background remover & more.',
    price_usd: 12.99,
    category: 'design-tools',
    image_url: 'https://upload.wikimedia.org/wikipedia/commons/thumb/b/bb/Canva_Logo.svg/200px-Canva_Logo.svg.png',
    badge: 'Popular',
  },
  {
    name: 'CapCut Pro 1 Month',
    description: 'Advanced video editing with AI tools, effects & export.',
    price_usd: 7.99,
    category: 'design-tools',
    image_url: 'https://upload.wikimedia.org/wikipedia/commons/thumb/7/70/CapCut_Logo.svg/200px-CapCut_Logo.svg.png',
    badge: 'New',
  },
]
