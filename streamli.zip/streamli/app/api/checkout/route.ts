import { NextRequest, NextResponse } from 'next/server'
import { stripe } from '@/lib/stripe'
import { createAdminClient } from '@/lib/supabase'
import { createServerComponentClient } from '@supabase/auth-helpers-nextjs'
import { cookies } from 'next/headers'
import { CURRENCIES, Currency } from '@/types'

export async function POST(req: NextRequest) {
  try {
    const { productId, currency = 'MAD' } = await req.json()

    // Authenticate user
    const supabaseAuth = createServerComponentClient({ cookies })
    const { data: { session } } = await supabaseAuth.auth.getSession()

    if (!session) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    // Fetch product
    const supabase = createAdminClient()
    const { data: product, error: productError } = await supabase
      .from('products')
      .select('*')
      .eq('id', productId)
      .eq('is_active', true)
      .single()

    if (productError || !product) {
      return NextResponse.json({ error: 'Product not found' }, { status: 404 })
    }

    // Calculate local amount
    const currencyConfig = CURRENCIES.find(c => c.code === currency)!
    const amountLocal = Math.round(product.price_usd * currencyConfig.rate)

    // Stripe uses smallest currency units (cents for USD)
    // For display, we use USD but show prices in local currency
    const stripeAmount = Math.round(product.price_usd * 100) // cents in USD

    const appUrl = process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000'

    // Create Stripe session
    const session_stripe = await stripe.checkout.sessions.create({
      payment_method_types: ['card'],
      mode: 'payment',
      line_items: [
        {
          price_data: {
            currency: 'usd',
            product_data: {
              name: product.name,
              description: product.description,
              images: product.image_url ? [product.image_url] : undefined,
              metadata: {
                product_id: product.id,
                category: product.category,
              },
            },
            unit_amount: stripeAmount,
          },
          quantity: 1,
        },
      ],
      metadata: {
        product_id: product.id,
        user_id: session.user.id,
        currency: currency,
        amount_local: amountLocal.toString(),
        amount_usd: product.price_usd.toString(),
      },
      customer_email: session.user.email,
      success_url: `${appUrl}/dashboard?success=true&session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${appUrl}/marketplace?canceled=true`,
      allow_promotion_codes: true,
    })

    // Create pending order in database
    await supabase.from('orders').insert({
      user_id: session.user.id,
      product_id: product.id,
      amount_usd: product.price_usd,
      currency: currency,
      amount_local: amountLocal,
      status: 'pending',
      stripe_session_id: session_stripe.id,
    })

    return NextResponse.json({ url: session_stripe.url })
  } catch (err: any) {
    console.error('Checkout error:', err)
    return NextResponse.json(
      { error: err.message || 'Internal server error' },
      { status: 500 }
    )
  }
}
